To get the RD to work with the 24RL system has been a real headache.  I finally got it to work with one caveat.  YOu apply the brakes with the RD and do all your brake pipe reductions using the hold quadrant to hold your set.  You will notice the RD does not release the brakes.  To do this you must hit the ";" button like you would when using the keyboard exclusively.  I think this is a small price to pay to be able to use the RD for running older diesels with the 24RL system.

If you choose to use the RD for running the 24RL system then replace the "Pro_24RL" folder in the "BrakeFiles_Pro" folder with the one in the "Pro_24RL Raildriver" folder.

Bill Prieger