TAnyImage

Derived from TImage

This is an enhanced TImage with all the normal TImage properties and
methods along with a few additional ones. Primarily that it can load
and display images in any format supported by mwgfx.dll.

Note that mwgfx.dll needs to be on the system of any one using programs
that utilise this component. The latest version can be obtained from
http://www.fly.to/mwgfx/

Note also that it has only been tested on the following :-

C++Builder 1.0
C++Builder 3
Delphi 2.0
Delphi 7.0 

Extra Properties :-

====================================================================
Runtime and Design Time Properties available in the Object Inspector
====================================================================

bool AutoFlush       - If true then mwgfx.dll is loaded before each use and
                       unloaded automatically afterwards.
                       If false then the component keeps hold of the
                       DLL handle and uses the same instance each time it
                       needs to access a function. The DLL will be unloaded
                       only when the component is destroyed.

bool CenterOnParent  - If true then the component is moved so that it
                       will be centred on the Parent component. If the 
                       Parent is resized the image will move to remain
                       centred (useful with resizable Forms)
                       Note that this functionis only checked when a new
                       image is loaded or some factor is changed. If you
                       wish it to re-centre when the form is resized then
                       you need to set it false and then true again in the 
                       Form's OnResize handler

AnsiString FileName  - This is the important one. Set this property and
                       if it points to a supported image file this image
                       will be converted to viewable by mwgfx.dll and
                       loaded into the Bitmap of the component.  
                       If FileName points to a  WMF, ICO or EMF file
                       then the TImage functions are used to load it
                       instead of mwgfx. Note that if you are distributing
                       your program to other users they are unlikely to
                       have the same paths as you so this property is best
                       set at runtime where you can calculate a suitable
                       path. If you wish the component to contain a fixed
                       image on startup then use the Picture property just
                       as with TImage

Jpegscale JpegScale  - This sets the value to be used by mwgfx when 
                       converting Jpeg images. 3 possible valid values
                       jsFull, jsHalf, jsQuarter. Actually an int (0,1,2)
                       Changing this setting when a Jpeg image is loaded 
                       will cause it to be reloaded with the new settings. 

Pcdsize PCDSize      - As JpegScale but sets the size to extract from a
                       PhotoCD file (p768x512, p384x256, p192x128)
                       Changing this setting when a PCD image is loaded 
                       will cause it to be reloaded with the new settings. 

bool Proportional    - If true then resizing of the component will be
                       forced to conform to the proportions of the
                       currently loaded image

bool TruColor        - If true then the image will be loaded in full
                       colour. If false then the image will be dithered
                       to 256 colours. Changing this setting when any
                       image is loaded will cause it to be reloaded with
                       the new settings. 

=======================
Runtime only Properties
=======================

PROGPROC Progress    - This gives access to the progress entry in the
                       Pic structure used by the component. You can set 
                       this to point to a progress-bar routine in the
                       same way as when working with mwgfx directly

struct Pic*PicData   - This gives you access to the Pic structure used
                       by the component. You can use this to read the
                       information contained. eg PicData->width,
                       PicData->comment and so on. See the Pic.h file
                       for details of the Pic entries (or get the mwgfx
                       developers kit for a full explanation).

=================
Notes on Versions
=================

The builder1 folder contains the source for the component in the format
required by CBuilder 1.0. Use the Install component function and select
anyimage.cpp from this folder

The builder3+ folder contains the source of the component in the PACKAGE
format required by CBuilder 3 and later versions. Use the Install component
function and select anyimage.cpp from here. It can be installed into one
of your existing packages or you can create a new one

The Delphi foldercontains the source of the component in Delphi format.
Select Install component and select anyimage.pas from here

==================
Notes on mwgfx.dll
==================

mwgfx.dll (actually a set of several dlls) is a windows runtime library
for the conversion and processing of image files in many formats. If is
regularly updated with new features and new image formats so any program
that uses it can gain access to new formats simply by the user installing 
the new version of the DLL set.

It supports most of the "usual" formats (Bmp, Tiff, Jpeg, Gif, Png etc)
and it also supports some more obscure, usually game-related, formats

At the time of writing it supports the reading of the following formats,
all of which should be displayable by the TAnyImage component

BMP (Standard)			All standard Windows Bitmap (BMP) formats.
                                2 Colour,16 Colour, 256 Colour,24 Bit,RLE
BMP (Special)	                WindowsNT 16 bit Formats 444,555,565, 
                                WindowsNT 32 bit, FS70 DXT1, DXT3 and DXT5	
PBMPlus			        PPM 24 bit ASCII (P3) and Binary (P6)
				PGM 256 Greyscale ASCII (P2) and Binary (P5)
				PBM Monochrome Binary (P4)	
Amiga IFF			All IFF-ILBM formats except EHB	
Compuserve Gif			Gif87a and Gif89a	
Jpeg/JFIF			24 bit and Greyscale 	
PhotoCD			        All sizes up to 768x512	
Aldus Tiff			All Standard Tiff formats	
Targa				All standard Targa formats	
PCX				All standard PCX formats	
Portable Network Graphics	All standard PNG formats	
Flight Simulator Raw		Standard and Compressed R8 formats	
Train Simulator ACE		All ACE formats	
DirectDrawSurface		All DDS formats (using mwdds.dll)
DTX				Most DTX formats

The TAnyImage can be used as a simple converter of any of these image 
formats to standard windows BMP by simply loading in the chosen image
and then using the TAnyImage->Picture->Bitmap->SaveToFile() method
inherited from TImage	


   

