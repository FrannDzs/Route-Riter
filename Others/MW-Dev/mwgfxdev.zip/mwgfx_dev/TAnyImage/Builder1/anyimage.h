//---------------------------------------------------------------------------
#ifndef AnyImageH
#define AnyImageH
//---------------------------------------------------------------------------
#include <vcl\SysUtils.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
#include "pic.h"

typedef bool (*MWGFXPROC)(char*,char*,struct Pic*,int,int);
typedef bool (*MWGFXVALID)(char*);
typedef void (*PROGPROC)(int,int);

#ifndef ENUMJPEG
#define ENUMJPEG
enum Jpegscale {jsFull,jsHalf,jsQuarter};
enum Pcdsize{p192x128,p384x256,p768x512};
#endif


//---------------------------------------------------------------------------
class TAnyImage : public TImage
{
private:
    HINSTANCE FLib;
    MWGFXPROC FProc;
    MWGFXVALID FValid;
    System::AnsiString FTemp;
    System::AnsiString FFileName;
    System::AnsiString FFileExt;
    struct Pic* pic;
    Jpegscale FJpeg;
    Pcdsize FPCD;
    bool FIs256;
    bool FAutoFlush;
    bool FProp;
    bool FCenter;
    char FDir[256];
    System::AnsiString FTempDir;
    PROGPROC Fprogress;

protected:
    virtual void __fastcall setfile(System::AnsiString FileName);
    virtual void __fastcall setjpeg(Jpegscale JpegScale);
    virtual void __fastcall setpcd(Pcdsize PCDSize);
    virtual void __fastcall set256(bool cmap);
    virtual void __fastcall setflush(bool flush);
    virtual void __fastcall setprop(bool prop);
    virtual void __fastcall setcenter(bool center);
    virtual void __fastcall StretchProp(void);

public:
    __fastcall TAnyImage(TComponent* Owner);
    virtual __fastcall ~TAnyImage(void);
    void __fastcall LoadAnyFromFile(System::AnsiString file);
    void __fastcall Flush(void);
    __property PROGPROC Progress={read=Fprogress,write=Fprogress};
    __property struct Pic*PicData={read=pic};

__published:
   __property Jpegscale JpegScale={read=FJpeg,write=setjpeg,default=jsFull};
   __property Pcdsize PCDSize={read=FPCD,write=setpcd,default=p768x512};
   __property System::AnsiString FileName={read=FFileName,write=setfile};
   __property bool TruColor={read=FIs256,write=set256,default=True};
   __property bool AutoFlush={read=FAutoFlush,write=setflush,default=True};
   __property bool CenterOnParent={read=FCenter,write=setcenter,default=True};
   __property bool Proportional={read=FProp,write=setprop,default=True};
};
//---------------------------------------------------------------------------
#endif
