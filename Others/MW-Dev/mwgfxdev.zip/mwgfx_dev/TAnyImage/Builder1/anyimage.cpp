//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "AnyImage.h"

//---------------------------------------------------------------------------
static inline TAnyImage *ValidCtrCheck()
{
	return new TAnyImage(NULL);
}
//---------------------------------------------------------------------------
__fastcall TAnyImage::TAnyImage(TComponent* Owner)
	: TImage(Owner)
{
pic=new struct Pic;
memset(pic,0,sizeof(struct Pic));
FPCD=p768x512;
FJpeg=jsFull;
Fprogress=NULL;
FLib=NULL;
FProp=FIs256=FAutoFlush=FCenter=True;
ExpandEnvironmentStrings("%temp%",FDir,250);
FTempDir=AnsiString(FDir);
if(FTempDir=="%temp%")
        {
        ExpandEnvironmentStrings("%tmp%",FDir,250);
        FTempDir=AnsiString(FDir);
        }
if(FTempDir[FTempDir.Length()]!='\\')FTempDir+="\\";

}
__fastcall TAnyImage::~TAnyImage(void)
{
Flush();
delete pic;
}

void __fastcall TAnyImage::setfile(System::AnsiString FileName)
{
if(FileName==FFileName)return;
FFileName=FileName;
LoadAnyFromFile(FFileName);
}
void __fastcall TAnyImage::StretchProp(void)
{
double p1,p2;
int w,h;

p1=(double)Picture->Width/(double)Picture->Height;	//picture proportions
p2=(double)Picture->Height/(double)Picture->Width;
w =(int)((double)Height*p1);
h=Height;
if(w>Width)
	{
    h=(int)((double)Width*p2);
    w=Width;
    }
if(FCenter)
	{
    if(w<Parent->ClientWidth)Left=(Parent->ClientWidth-w)/2;
    if(h<Parent->ClientHeight)Top=(Parent->ClientHeight-h)/2;
    }
if(w!=Width)Width=w;
if(h!=Height)Height=h;

}
void __fastcall TAnyImage::setprop(bool prop)
{
FProp=prop;
if(FProp)
	{
    AutoSize=False;
    Stretch=True;
    StretchProp();
    }
}
void __fastcall TAnyImage::setcenter(bool center)
{
if(center==FCenter)return;
FCenter=center;
if(FCenter)LoadAnyFromFile(FFileName);
}
void __fastcall TAnyImage::set256(bool cmap)
{
if(cmap==FIs256)return;
FIs256=cmap;
LoadAnyFromFile(FFileName);
}
void __fastcall TAnyImage::Flush(void)
{
if(FLib)FreeLibrary(FLib);
FLib=NULL;
}
void __fastcall TAnyImage::setflush(bool flush)
{
FAutoFlush=flush;
Flush();
}
void __fastcall TAnyImage::setjpeg(Jpegscale JpegScale)
{
if(JpegScale==FJpeg)return;
FJpeg=JpegScale;
if(FJpeg>jsQuarter)FJpeg=jsQuarter;
if(FJpeg<jsFull)FJpeg=jsFull;
if(FFileExt==".JPG")LoadAnyFromFile(FFileName);
}
void __fastcall TAnyImage::setpcd(Pcdsize PCDSize)
{
if(FPCD==PCDSize)return;
FPCD=PCDSize;
if(FPCD>p768x512)FPCD=p768x512;
if(FPCD<p192x128)FPCD=p192x128;
if(FFileExt==".PCD")LoadAnyFromFile(FFileName);
}
void __fastcall TAnyImage::LoadAnyFromFile(System::AnsiString file)
{
FFileName=file;
FFileExt=ExtractFileExt(file);
FFileExt=FFileExt.UpperCase();

if(FFileExt==".ICO" || FFileExt==".WMF" || FFileExt==".EMF")
	{
    Picture->LoadFromFile(file);
    return;
    }

 pic->progress=NULL;
 if(Fprogress)pic->progress=Fprogress;
if(!FLib)FLib=LoadLibrary("mwgfx");
if(!FLib)
	{
    MessageBox(GetFocus(),"Cannot find mwgfx.dll","AnyImage",MB_OK|MB_ICONERROR);
	return;
	}
if(FIs256)FProc=(MWGFXPROC) GetProcAddress(FLib, "_anytobmps");
else      FProc=(MWGFXPROC) GetProcAddress(FLib, "_anyto256");
FValid=(MWGFXVALID) GetProcAddress(FLib,"_Pic_Valid");
if((!FProc)||(!FValid))
	{
    MessageBox(GetFocus(),"Cannot find Routine","MWGfx",MB_OK|MB_ICONERROR);
    }
else
	{

    FTemp=FTempDir+"x"+ExtractFileName(file);

    FTemp=FTemp.SubString(1,FTemp.Length()-FFileExt.Length());
    FTemp+=".bmp";
    if((FValid)(file.c_str()))
    	{
    	if((FProc)(file.c_str(),FTemp.c_str(),pic,FPCD+1,FJpeg))
    		{
        	Picture->LoadFromFile(FTemp);
            if(FProp)StretchProp();
        	}
        }
    _unlink (FTemp.c_str());
    }
if(FAutoFlush)Flush();

}
//---------------------------------------------------------------------------
namespace Anyimage
{
	void __fastcall Register()
	{
		TComponentClass classes[1] = {__classid(TAnyImage)};
		RegisterComponents("MW", classes, 0);
	}
}
//---------------------------------------------------------------------------
