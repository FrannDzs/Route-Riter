#ifndef PIC_H
#define PIC_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
//#include <windows.h>
#define UBYTE unsigned char

// This file sets up the core Pic structure used by mwgfx.dll
// and the basic Bmp header struct
struct Pic
{
	long width;
    long height;
    long depth;
    long numcols;
    FILE* fin;
    char comment[80];
    unsigned char cmap[768];
    void* jlib;
    void* tlib;
    void* plib; 
	unsigned char*buff;
    FILE* fout;
    void *ptr;
	void(*progress)(int,int);
	void* ilib;
	long stype;
	unsigned char spare[120];
};

struct BitMapInfo
{

    long biSize;
    long biWidth;
    long biHeight;
    short biPlanes;
    short biBitCount;
    long biCompression;
    long biSizeImage;
    long biXPelsPerMeter;
    long biYPelsPerMeter;
    long numcols;
    long biClrImportant;
};
//macros

#define Request(title,text) MessageBox(GetFocus(),text,title,MB_YESNO|MB_ICONQUESTION)
#define ReqInfo(title,text) MessageBox(GetFocus(),text,title,MB_OK|MB_ICONINFORMATION)
#define ReqError(title,text) MessageBox(GetFocus(),text,title,MB_OK|MB_ICONERROR)
#define ReqOK IDOK
#define ReqYES IDYES
#define ReqNO IDNO
enum{P_ROTATE,P_RGB24,P_DITHER,P_GREY,P_FOCUS,
	 P_SMOOTH,P_CONTRASTUP,P_CONTRASTDOWN};

#endif