//---------------------------------------------------------------------------
#include <vcl\condefs.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma hdrstop
#include "mwgfx.h"
//---------------------------------------------------------------------------
USELIB("Mwgfx.lib");
USERES("mwver.res");
USERES("Any2Bmp.res");
//---------------------------------------------------------------------------
char*tex=
        "Any2Bmp <infile> <outbmp>\n"
        "This program uses mwgfx.dll to convert any\n"
        "supported Image files to Standard BMP format\n"
        ;
struct Pic pic;
//Progress callback routine
void myprogress(int a, int b)
{
	printf("%d %% %c",(a*100)/b,13);
}
int main(int argc, char **argv)
{
 	if(argc!=3)
		{
        printf(tex);
        return 0;
        }
	pic.progress=myprogress;
	if(anytobmps(argv[1],argv[2],&pic,0,0))
		{
		printf("File   : %s\n",argv[1]);
		printf("Type   : %s\n",pic.comment);
		printf("Width  : %d\n",pic.width);
		printf("Height : %d\n",pic.height);
		printf("Output : %s\n",argv[2]);
		printf("Format : Windows Bitmap\n");
		printf("Depth  : %d bit\n",pic.depth);
		printf("Colours: %d\n",pic.numcols);
		printf("\n");
		}
	else printf("Error processing %s\n",argv[1]);
	return 0;
}
//---------------------------------------------------------------------------
