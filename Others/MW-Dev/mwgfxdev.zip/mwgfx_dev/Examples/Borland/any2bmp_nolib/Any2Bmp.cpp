//---------------------------------------------------------------------------
#include <vcl\condefs.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>


#pragma hdrstop
#include "mwgfx.h"
//---------------------------------------------------------------------------
USERES("mwver.res");
USERES("Any2Bmp.res");
//---------------------------------------------------------------------------
char*tex=
        "Any2Bmp <infile> <outbmp>\n"
        "This program uses mwgfx.dll to convert\n"
        "any Image files to Standard BMP format\n"
        ;
struct Pic pic;

//define a type for the required function call
typedef int (*MYPROC)(char*,char*,struct Pic*,int, int);

int main(int argc, char* argv[])
{
int result=0;
HINSTANCE mylib;
MYPROC myproc;


    if(argc!=3)
    {
		printf(tex);
        return 0;
    }
	//load the DLL
	mylib=LoadLibrary("mwgfx");
    if(mylib)
    {
		//locate the function (note the added underscore)
		myproc=(MYPROC)GetProcAddress(mylib,"_anytobmps");
		if(myproc)
		{
			//Execute the function
			result= (*myproc)(argv[1],argv[2],&pic,0,0);
			if(result)
			{
				//print out some data from the Pic struct
				printf("File   : %s\n",argv[1]);
				printf("Type   : %s\n",pic.comment);
				printf("Width  : %d\n",pic.width);
				printf("Height : %d\n",pic.height);
				printf("Output : %s\n",argv[2]);
				printf("Format : Windows Bitmap\n");
				printf("Depth  : %d bit\n",pic.depth);
				printf("Colours: %d\n",pic.numcols);
			}
			else printf("Problem Converting this Image\n");
		}
		else printf("Unable to access DLL function\n");
		FreeLibrary(mylib);
	}
	else printf("Unable to open DLL\n");

   return result;

}

//---------------------------------------------------------------------------
