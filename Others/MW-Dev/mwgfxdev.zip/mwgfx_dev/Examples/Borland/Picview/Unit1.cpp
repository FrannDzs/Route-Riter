//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "mwgfx.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"

char* tempfile="c:\\devpak.bmp";
struct Pic pic;
TForm1 *Form1;

void MyProgress(int a,int b)
{
Form1->ProgressBar1->Position=(a*100)/b;
}
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
pic.progress=MyProgress;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::LoadImage1Click(TObject *Sender)
{
if(OpenDialog1->Execute())
        {
        OpenDialog1->InitialDir=ExtractFilePath(OpenDialog1->FileName);
        if(Pic_Valid(OpenDialog1->FileName.c_str()))
                {
                if(anytobmps(OpenDialog1->FileName.c_str(),tempfile,&pic,0,0))
                        {
                        ProgressBar1->Position=0;
                        Image1->Picture->Bitmap->LoadFromFile(AnsiString(tempfile));
                        StatusBar1->SimpleText=ExtractFileName(OpenDialog1->FileName)+"    "+AnsiString(pic.comment);
                        }
                else StatusBar1->SimpleText="Loading Error!!";
                }
        else StatusBar1->SimpleText=ExtractFileName(OpenDialog1->FileName)+" is not a readable image file!";
        }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
//delete the temporary file used for conversions
remove(tempfile);
}
//--------------------------------------------------------------------------- 