#ifndef MWGFXNOLIB
#define MWGFXNOLIB
//**********************************************
//
//  A set of functions so that mwgfx functions
//  can be called without using the linklibs
//
//
//  Do not include mwgfx.h if using this file
//
//**********************************************

//  necessary info from mwgfx.h
#ifndef MWGFX_H

#include <stdio.h>
#include <windows.h>
struct Pic
{
	long width;	
    	long height;
    	long depth;
    	long numcols;
    	FILE* fin;
    	char comment[80];
    	unsigned char cmap[768];
    	void* jlib;
    	void* tlib;
    	void* plib; 
	unsigned char*buff;
    	FILE* fout;
    	void *ptr;
	void(*progress)(int,int);
	void* ilib;
	long stype;
	unsigned char spare[120];
};

//targa function defines
#define TGA_ERROR_NOTTGA          1
#define TGA_ERROR_COMPRESSED      2
#define TGA_ERROR_NOTFOUND        3
#define TGA_ERROR_MONO            4
#define TGA_ERROR_INTERNAL        5
#define TGA_ERROR_DLL             6
#define TGA_ERROR_BADBMP24        7
#define TGA_ERROR_BADBMP8         8
#define TGA_ERROR_NOTDDS          9
#define TGA_ERROR_NOTEXTENDED    10
#define TGA_ERROR_NOTACE         11

#define TGA_OK                    0

#define TGA_WARNING_COMPRESSED   -1
#define TGA_WARNING_COLOURMAPPED -2
#define TGA_WARNING_GREYSCALE    -3
#define TGA_WARNING_16BIT        -4
#define TGA_WARNING_24BIT        -5

// TextureFormat for DDS etc output from Targa
#define TGA_DXT1            10
#define TGA_DXT1_1BitAlpha  11
#define TGA_DXT3            12
#define TGA_DXT5            13
#define TGA_RGB4444         14
#define TGA_RGB1555         15
#define TGA_RGB565          16
#define TGA_RGB8888         17
#define TGA_RGB888          18
#define TGA_RGB555          19
#define TGA_8Bit            20

#endif

//  Globals

HINSTANCE mylib;

//  typedefs

typedef int (*ANYTOBMPS)(char*,char*,struct Pic*,int, int);
ANYTOBMPS p_anytobmps;
ANYTOBMPS p_anytogrey;
ANYTOBMPS p_anyto256;


//  Function to load the DLL if necessary
int CheckLib(void)
{
if(!mylib)mylib=LoadLibrary("mwgfx");   //if dll not loaded then load it
if(!mylib)return 0;                     //fail
//now get the functions
p_anytobmps=(ANYTOBMPS)GetProcAddress(mylib,"_anytobmps");
p_anytogrey=(ANYTOBMPS)GetProcAddress(mylib,"_anytogrey");
p_anyto256= (ANYTOBMPS)GetProcAddress(mylib,"_anytobmps");
return 0;                               //fail
}

// functions

int anytobmps( char*infile,char*outfile,struct Pic*pic,int pcd, int jpg)
{
if(CheckLib())return 0;
return (*p_anytobmps)(infile,outfile,pic,pcd,jpg);
}
int anytogrey( char*infile,char*outfile,struct Pic*pic,int pcd, int jpg)
{
if(CheckLib())return 0;
return (*anytogrey)(infile,outfile,pic,pcd,jpg);
}
int anyto256( char*infile,char*outfile,struct Pic*pic,int pcd, int jpg)
{
if(CheckLib())return 0;
return (*anyto256)(infile,outfile,pic,pcd,jpg);
}

 
#endif