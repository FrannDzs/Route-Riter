// CPic.cpp
////////////////////////////////////////
// Derived from the CDib example in the 
// "Windows 98 Programming Bible" by
// Richard C. Leinecker and Tom Archer
// Published by IDG Books
////////////////////////////////////////
#include "stdafx.h"
#include "cpic.h"

CPic::CPic()
{
	Pic_Bmp = NULL;

}

CPic::~CPic()
{
	if( Pic_Bmp != NULL )delete [] Pic_Bmp;

}

BOOL CPic::Load( char *pszFilename, struct Pic*pic )
{
	CFile cf;
	unsigned char *pDib;
	DWORD dwDibSize;
	char tempfile[256];
	BITMAPFILEHEADER BFH;
	
	//find the TEMP folder
	GetTempPath(255,tempfile);
	
	//make sure it has a trailing slash
	if(tempfile[strlen(tempfile)-1]!='\\')strcat(tempfile,"\\");
	
	//add a suitable temp filename
	strcat(tempfile,"PicViewTmp.bmp");

	//convert the selected file to the temp file as Bmp
	if(!anytobmps(pszFilename,tempfile,pic,0,0))return(false);

	//open the temp file for reading
	if( !cf.Open( tempfile, CFile::modeRead ) )	return( FALSE );
	
	//get the size and allocate the required space
	dwDibSize =	cf.GetLength() - sizeof( BITMAPFILEHEADER );
	pDib = new unsigned char [dwDibSize];
	if( pDib == NULL )return( FALSE );

	// Read in the Dib header and data.
	cf.Read( &BFH, sizeof( BITMAPFILEHEADER ) );
	cf.Read( pDib, dwDibSize );
	
	// clear out any previous data
	if( Pic_Bmp != NULL )delete Pic_Bmp;

	// set up member variables.
	Pic_Bmp = pDib;
	Pic_DataSize = dwDibSize;
	Pic_BIH = (BITMAPINFOHEADER *) Pic_Bmp;
	Pic_RGB =(RGBQUAD *) &Pic_Bmp[sizeof(BITMAPINFOHEADER)];
	Pic_NumCols = 1 << Pic_BIH->biBitCount;
	if( Pic_BIH->biBitCount > 8 )Pic_NumCols = 0;
	else if( Pic_BIH->biClrUsed != 0 )Pic_NumCols = Pic_BIH->biClrUsed;
	Pic_BmpBits =&Pic_Bmp[sizeof(BITMAPINFOHEADER)+Pic_NumCols*sizeof(RGBQUAD)];

	// If we have a valid palette, delete it.
	if( Pic_Palette.GetSafeHandle() != NULL )	Pic_Palette.DeleteObject();

	// and allocate the new one.
	if( Pic_NumCols != 0 )
		{
		LOGPALETTE *pLogPal = (LOGPALETTE *) new char
				[sizeof(LOGPALETTE)+
				Pic_NumCols*sizeof(PALETTEENTRY)];
		if( pLogPal != NULL )
			{
			pLogPal->palVersion = 0x300;
			pLogPal->palNumEntries = Pic_NumCols;
			for( int i=0; i<Pic_NumCols; i++ )
				{
				pLogPal->palPalEntry[i].peRed =
					Pic_RGB[i].rgbRed;
				pLogPal->palPalEntry[i].peGreen =
					Pic_RGB[i].rgbGreen;
				pLogPal->palPalEntry[i].peBlue =
					Pic_RGB[i].rgbBlue;
				}
			Pic_Palette.CreatePalette( pLogPal );
			delete [] pLogPal;
			}
		}
	//remove the temporary file
	remove(tempfile);
	return( TRUE );

}



BOOL CPic::Draw( CDC *pDC, int nX, int nY, int nWidth, int nHeight )
{
	if( Pic_Bmp == NULL )return( FALSE );
	
	nWidth  = Pic_BIH->biWidth;
	nHeight = Pic_BIH->biHeight;

	// Use StretchDIBits to draw .
	StretchDIBits( pDC->m_hDC, nX, nY,
		nWidth, nHeight,
		0, 0,
		Pic_BIH->biWidth, Pic_BIH->biHeight,
		Pic_BmpBits,
		(BITMAPINFO *) Pic_BIH,
		BI_RGB, SRCCOPY );
	
	return( TRUE );

}
BOOL CPic::Save( char *pszFilename )
{

	// If we have no data, we can't save.
	if( Pic_Bmp == NULL )return( FALSE );

	CFile cf;

	// Attempt to create the file.
	if( !cf.Open( pszFilename,
		CFile::modeCreate | CFile::modeWrite ) )
		return( FALSE );
	
	// Write the data.
	try{

		// First, create a BITMAPFILEHEADER
		// with the correct data.
		BITMAPFILEHEADER BFH;
		memset( &BFH, 0, sizeof( BITMAPFILEHEADER ) );
		BFH.bfType = 'MB';
		BFH.bfSize = sizeof( BITMAPFILEHEADER ) + Pic_DataSize;
		BFH.bfOffBits = sizeof( BITMAPFILEHEADER ) +
			sizeof( BITMAPINFOHEADER ) +
			Pic_NumCols * sizeof( RGBQUAD );

		// Write the BITMAPFILEHEADER and the
		// Dib data.
		cf.Write( &BFH, sizeof( BITMAPFILEHEADER ) );
		cf.Write( Pic_Bmp, Pic_DataSize );
		}

	// If we get an exception, delete the exception and
	// return FALSE.
	catch( CFileException *e ){
		e->Delete();
		return( FALSE );
		}

	return( TRUE );

}


BOOL CPic::SetPalette( CDC *pDC )
{

	if( Pic_Bmp == NULL )return( FALSE );
	if( Pic_Palette.GetSafeHandle() == NULL )return( TRUE );
	CPalette *pOldPalette;
	pOldPalette = pDC->SelectPalette( &Pic_Palette, FALSE );
	pDC->RealizePalette();
	pDC->SelectPalette( pOldPalette, FALSE );

	return( TRUE );

}
