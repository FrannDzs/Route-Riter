// CPic.h

#ifndef __CPIC_H__
#define __CPIC_H__

#include "mwgfx.h"

class CPic
{

public:
	CPic();
	~CPic();
	BOOL Load( char *, struct Pic* );
	BOOL Save( char * );
	BOOL Draw( CDC *, int nX = 0, int nY = 0, int nWidth = -1, int nHeight = -1 );
	BOOL SetPalette( CDC * );
private:
	CPalette			Pic_Palette;
	unsigned char *		Pic_Bmp;
	unsigned char *		Pic_BmpBits;
	DWORD				Pic_DataSize;
	BITMAPINFOHEADER *	Pic_BIH;
	RGBQUAD *			Pic_RGB;
	int					Pic_NumCols;

};

#endif
