// PicView.h : main header file for the PICVIEW application
//

#if !defined(AFX_PICVIEW_H__69CC80FC_4AEA_4E21_BC92_AF016B5D075E__INCLUDED_)
#define AFX_PICVIEW_H__69CC80FC_4AEA_4E21_BC92_AF016B5D075E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CPicViewApp:
// See PicView.cpp for the implementation of this class
//

class CPicViewApp : public CWinApp
{
public:
	CPicViewApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPicViewApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CPicViewApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICVIEW_H__69CC80FC_4AEA_4E21_BC92_AF016B5D075E__INCLUDED_)
