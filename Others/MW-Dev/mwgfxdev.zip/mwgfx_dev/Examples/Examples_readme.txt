Examples for using mwgfx.dll with various programming tools

Note - The versions of mwgfx.h, mwgfx.lib, mwgfxvc.lib, mwgfx.bas and
       mwgfx.pas in the examples may not have been updated. 
       Replace with ones from the "Dev_files" folder before compiling

Examples are included for the following programming Systems :-

Borland C++/C++Builder
Borland Delphi 
Microsoft VC++
Microsoft Visual Basic

Things to note - I am primarily a C++Builder and Borland C++
programmer so don`t expect anything too fancy for the others.
They are all just very basic examples to illustrate the use
of mwgfx functions. 

They have been tested with the following but should work on
other versions as well.

C++Builder 1
Delphi 2
VC++ 6
VB 6


