//header file for C programs using mwgfx.dll
#ifndef MWGFX_H
#define MWGFX_H

#include <stdio.h>
#include <windows.h>
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
//#include <windows.h>
#define UBYTE unsigned char
struct Pic
{
	long width;	
	long height;
	long depth;
	long numcols;
	FILE* fin;
	char comment[80];
	unsigned char cmap[768];
	void* jlib;
	void* tlib;
	void* plib;
	unsigned char*buff;
	FILE* fout;
	void *ptr;
	void(*progress)(int,int);
	void* ilib;
	long stype;
	long return0;
	long return1;
	long return2;
	long return3;
	long return4;
	unsigned char spare[100];
};

//if MS VC++ then link library contains the function calling code
//For Borland call the DLL directly
#ifdef _MSC_VER
#define MWGFXFUNC extern "C"
#else
#define MWGFXFUNC extern "C" __declspec(dllimport)
#endif

//access to mwgfx24.dll functions

MWGFXFUNC void WinSlideShow(char*,int,int,int,int,int);
MWGFXFUNC void WinSlideShowSound(char*,int,int,int,int,int,char*,int,int);
MWGFXFUNC void WinImagePrint(char*);
MWGFXFUNC void WinImageCopy(char*);
MWGFXFUNC void WinImageShow(char*,int);
MWGFXFUNC int WinImageBrowse(char*);
MWGFXFUNC int WinImageAdjust(char*);
MWGFXFUNC int WinImageSize(char*);
MWGFXFUNC int WinImageCrop(char*,int,int,int,int);
MWGFXFUNC void WinVideoShow(char*,int,int,int,int,int);
MWGFXFUNC void WinVideoScreen(char*,int,int,int,int);
MWGFXFUNC int WinImageScan(char*);

//winapi functions

MWGFXFUNC void MWGrabWindow(char*);
MWGFXFUNC void MWGrabScreen(char*);
MWGFXFUNC void MWSetWallpaper(char*,struct Pic*,char*,int);
MWGFXFUNC int MWOpenImageDialog(char*,char*);
MWGFXFUNC int MWOpenImageDialogEx(char*,char*,char*,char*,int,int,int,int);
MWGFXFUNC int MWOpenVideoDialog(char*,char*);

MWGFXFUNC int Pic_Convert(char*,char*,struct Pic*,int,int,int,int);

//high level routines - read file into pic

MWGFXFUNC int Pic_Read(char*,struct Pic*,int,int);
MWGFXFUNC int Pic_Write(char*,struct Pic*,int);


//convert supported files to bmp

MWGFXFUNC int anytobmps(char*,char*,struct Pic*,int,int);
MWGFXFUNC int anyto256(char*,char*,struct Pic*,int,int);
MWGFXFUNC int anytogrey(char*,char*,struct Pic*,int,int);
MWGFXFUNC int anytobmp(char*,char*,struct Pic*,int);
MWGFXFUNC int checkbmp(char*,struct Pic*);

//convert bmp to supported save format

MWGFXFUNC int bmptoanys(char*,char*,struct Pic*,int,int);

//read any format into memory as a BMP

MWGFXFUNC HGLOBAL LoadAsBitmap(char*,struct Pic*);
MWGFXFUNC HGLOBAL FreeBitmapMemory(HGLOBAL);
MWGFXFUNC HGLOBAL LoadAsDIB(char*,struct Pic*);
MWGFXFUNC HGLOBAL LoadAsDIB2(char*,struct Pic*,int,int);

//information on Image file or dll facilities

MWGFXFUNC int Pic_Valid(char*);
MWGFXFUNC int Pic_ValidExt(char*,int);
MWGFXFUNC int Pic_ExtValid(char*);
MWGFXFUNC char* Pic_Description(int);
MWGFXFUNC char* Pic_Extension(int);
MWGFXFUNC char* Pic_Pattern(int);
MWGFXFUNC char* Pic_Copyright(int);
MWGFXFUNC int Pic_Count(void);
MWGFXFUNC void Pic_Version(int*,int*);
MWGFXFUNC char* Pic_GetSaveFormats(void);
MWGFXFUNC int Pic_GetSaveFormat(int);
MWGFXFUNC char* Pic_Extensions(void);

//process a bmp file to a bmp file

MWGFXFUNC void bmprotate(char*,char*,struct Pic*,int);
MWGFXFUNC void bmprocess(char*,char*,struct Pic*,int);
MWGFXFUNC void bmpcrop(char*,char*,struct Pic*,int,int,int,int);
MWGFXFUNC void bmpprocess(char*,char*,struct Pic*,int,int,int,int,int);
MWGFXFUNC void bmpsharpen(char*,char*,struct Pic*,double);
MWGFXFUNC void bmpremap(char*,char*,struct Pic*,char*);
MWGFXFUNC void bmpresize(char*,char*,struct Pic*,int,int);
MWGFXFUNC void bmpmerge(char*,char*,struct Pic*,char*);
MWGFXFUNC void bmpinsert(char*,char*,struct Pic*,char*,int,int);

//scan with mwtwack

MWGFXFUNC int SelectScanSource(int);
MWGFXFUNC int ScanToFile(int,char*);

//specials
MWGFXFUNC int ExtractGIF(char*,char*,struct Pic*,int);

//process Pic

MWGFXFUNC void Pic_RGB24 (struct Pic*);
MWGFXFUNC void Pic_Dither(struct Pic*);
MWGFXFUNC void Pic_Rotate(struct Pic*);
MWGFXFUNC void Pic_Crop(struct Pic*,int,int,int,int);

//targa functions
MWGFXFUNC int TargaSplit(char*,char*,char*,struct Pic*);
MWGFXFUNC int TargaJoin(char*,char*,char*,struct Pic*);
MWGFXFUNC char* TargaMessage(int);
MWGFXFUNC void TargaGetMessage(int,struct Pic*);
MWGFXFUNC int TargaResize(char*,char*,struct Pic*,int,int);
MWGFXFUNC int TargaCrop(char*,char*,struct Pic*,int,int,int,int);
MWGFXFUNC int TargaFlip(char*,char*,struct Pic*);

MWGFXFUNC int TargaToDDS(char*,char*,struct Pic*,int);
MWGFXFUNC int TargaFromDDS(char*,char*,struct Pic*);
MWGFXFUNC int TargaToExtendedBitmap(char*,char*,struct Pic*,int);
MWGFXFUNC int TargaFromExtendedBitmap(char*,char*,struct Pic*);
MWGFXFUNC int TargaToACE(char*,char*,struct Pic*,int);
MWGFXFUNC int TargaFromACE(char*,char*,struct Pic*);
MWGFXFUNC int TargaFromAny(char*,char*,struct Pic*);
MWGFXFUNC int TargaFromPNG(char*,char*,struct Pic*);
MWGFXFUNC int TargaToPNG(char*,char*,struct Pic*);
MWGFXFUNC int TargaFromTIF(char*,char*,struct Pic*);
MWGFXFUNC int TargaToTIF(char*,char*,struct Pic*,int);
MWGFXFUNC int TargaToCA(char*,char*,struct Pic*,int);
MWGFXFUNC int TargaFromCA(char*,char*,struct Pic*);
MWGFXFUNC int TargaToIWI(char*,char*,struct Pic*,int);
MWGFXFUNC int TargaFromIWI(char*,char*,struct Pic*);
MWGFXFUNC int TargaFromTGP(char*,char*,struct Pic*);

//targa function defines

#define TGA_ERROR_NOTTGA          1
#define TGA_ERROR_COMPRESSED      2
#define TGA_ERROR_NOTFOUND        3
#define TGA_ERROR_MONO            4
#define TGA_ERROR_INTERNAL        5
#define TGA_ERROR_DLL             6
#define TGA_ERROR_BADBMP24        7
#define TGA_ERROR_BADBMP8         8
#define TGA_ERROR_NOTDDS          9
#define TGA_ERROR_NOTEXTENDED    10
#define TGA_ERROR_NOTACE         11

#define TGA_OK                    0

#define TGA_WARNING_COMPRESSED   -1
#define TGA_WARNING_COLOURMAPPED -2
#define TGA_WARNING_GREYSCALE    -3
#define TGA_WARNING_16BIT        -4
#define TGA_WARNING_24BIT        -5

// TextureFormat for DDS etc output from Targa

#define TGA_DXT1            	10
#define TGA_DXT1_1BitAlpha  	11
#define TGA_DXT3            	12
#define TGA_DXT5            	13
#define TGA_RGB4444         	14
#define TGA_RGB1555         	15
#define TGA_RGB565          	16
#define TGA_RGB8888         	17
#define TGA_RGB888          	18
#define TGA_RGB555          	19
#define TGA_8Bit            	20

//save formats for bmptoanys

#define FORMAT_BMP				1
#define FORMAT_JPEG				2
#define FORMAT_JPEG_GREY		3
#define FORMAT_TIFF				4
#define FORMAT_TIFF_LZW			5
#define FORMAT_TIFF_PACKBITS	6
#define FORMAT_TIFF_FAX3		7
#define FORMAT_TIFF_FAX4		8
#define FORMAT_PNG				9
#define FORMAT_GIF				10
#define FORMAT_PPM				11
#define FORMAT_PGM				12
#define FORMAT_PBM				13
#define FORMAT_IFF				14
#define FORMAT_RAW				15
#define FORMAT_BMP_565			16
#define FORMAT_BMP_4444			17
#define FORMAT_BMP_8888			18
#define FORMAT_BMP_5551			19
#define FORMAT_BMP_DXT1			20
#define FORMAT_ACE_DXT1			21
#define FORMAT_DDS_DXT1			22
#define FORMAT_TGA_24			23
#define FORMAT_TGA_32			24

#endif



