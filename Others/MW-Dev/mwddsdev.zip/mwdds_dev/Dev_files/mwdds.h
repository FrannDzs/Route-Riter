/*=========================================================
	
	Header file for MWDDS.DLL

	copyright (c) 2002-2004 Martin Wright

==========================================================*/	

#ifndef MWDDS
#define MWDDS

//Options for Mip filtering
enum MIPFilterTypes
{
    kMIPFilterPoint ,    
    kMIPFilterBox ,      
    kMIPFilterTriangle , 
    kMIPFilterQuadratic ,
    kMIPFilterCubic ,    
    kMIPFilterCatrom ,   
    kMIPFilterMitchell , 
    kMIPFilterGaussian , 
    kMIPFilterSinc ,     
    kMIPFilterBessel ,   
    kMIPFilterHanning ,  
    kMIPFilterHamming ,  
    kMIPFilterBlackman , 
    kMIPFilterKaiser,
    kMIPFilterLast,
};
//options for Mip processing
enum SharpenFilterTypes
{
    kSharpenFilterNone,
    kSharpenFilterNegative,
    kSharpenFilterLighter,
    kSharpenFilterDarker,
    kSharpenFilterContrastMore,
    kSharpenFilterContrastLess,
    kSharpenFilterSmoothen,
    kSharpenFilterSharpenSoft,
    kSharpenFilterSharpenMedium,
    kSharpenFilterSharpenStrong,
    kSharpenFilterFindEdges,
    kSharpenFilterContour,
    kSharpenFilterEdgeDetect,
    kSharpenFilterEdgeDetectSoft,
    kSharpenFilterEmboss,
    kSharpenFilterMeanRemoval,
    kSharpenFilterUnSharp,
    kSharpenFilterXSharpen,
    kSharpenFilterWarpSharp,
    kSharpenFilterCustom,
    kSharpenFilterLast,
};

#ifndef _MSC_VER
//LinkLib Aliasing for Borland
#define _DXTSetMipFilter	DXTSetMipFilter
#define _DXTSetMipSharpen	DXTSetMipSharpen
#define _DXTcompress		DXTcompress
#define _DXTcreateMIPS		DXTcreateMIPS
#define _DXTcompressACE		DXTcompressACE
#define _TGAcompressBMP		TGAcompressBMP
#define _TGAcompressDDS		TGAcompressDDS
#define _TGAcompressACE		TGAcompressACE
#define _BMPScompressBMP	BMPScompressBMP
#define _CombineAlphaDXT1	CombineAlphaDXT1
#define _DDStoTGA		DDStoTGA
#define _TGAtoACE		TGAtoACE
#define _TGAtoDDS		TGAtoDDS
#define _TGAtoBMP		TGAtoBMP
#define _TGAtoBMPS		TGAtoBMPS
#define _BMPStoTGA		BMPStoTGA
#endif

extern "C" __declspec(dllimport) int  DXTSetMipFilter(short typ);
extern "C" __declspec(dllimport) int  DXTSetMipSharpen(short typ);

extern "C" __declspec(dllimport) int  DXTcompress(
		unsigned char * raw_data, 	// pointer to data (24 or 32 bit)
                unsigned long w, 		// width in texels
                unsigned long h, 		// height in texels
                DWORD TextureFormat, 		// list below
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                DWORD depth, 			// 3 or 4 (RGB or RGBA)
                void* callback,			// callback function
                char* fname);  			// output DDS filename

extern "C" __declspec(dllimport) int  DXTcompressBMP(
		unsigned char * raw_data, 	// pointer to data (24 or 32 bit)
                unsigned long w, 		// width in texels
                unsigned long h, 		// height in texels
                DWORD TextureFormat, 		// list below
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                DWORD depth, 			// 3 or 4
                char* fname); 			// output BMP filename 

extern "C" __declspec(dllimport) int  DXTcreateMIPS(
		unsigned char * raw_data, 	// pointer to data (24 or 32 bit)
                unsigned long w, 		// width in texels
                unsigned long h, 		// height in texels
                DWORD TextureFormat, 		// list below
                bool bDither,			// use dither for 16 bit
                DWORD depth, 			// 3 or 4
                char* fname);  			// basename for mip files

extern "C" __declspec(dllimport) int  DXTcompressACE(
		unsigned char * raw_data, 	// pointer to data (24 or 32 bit)
                unsigned long w, 		// width in texels
                unsigned long h, 		// height in texels
                DWORD TextureFormat, 		// list below (DXT1/DXT1a only)
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                DWORD depth, 			// 3 or 4
                char* fname);			// output ACE filename

extern "C" __declspec(dllimport) int TGAcompressBMP(
		char * infile, 			// TGA file
                DWORD TextureFormat, 		// list below
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                char*fname);			// output BMP filename

extern "C" __declspec(dllimport) int TGAcompressDDS(
		char * infile, 			// TGA file
                DWORD TextureFormat, 		// list below
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                char*fname);			// output DDS filename

extern "C" __declspec(dllimport) int TGAcompressACE(
		char * infile, 			// TGA file
                DWORD TextureFormat, 		// list below (DXT1 or DXT1a only!)
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                char*fname);			// output ACE filename

extern "C" __declspec(dllimport) int BMPScompressBMP(
		char * infile, 			// 24 bit Bmp file
		char* alpha,			// 8 bit greyscale Alpha Bmp
                DWORD TextureFormat, 		// list below
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                char*fname);			// output BMP filename

extern "C" __declspec(dllimport) int CombineAlphaDXT1(
		char * infile, 			// 24 bit Bmp file
		char* alpha,			// 8 bit greyscale Alpha Bmp
                char*fname);			// output BMP filename

extern "C" __declspec(dllimport) int DDStoTGA(
		char * infile, 			// DDS file
		char*fname);   			// output targa filename

extern "C" __declspec(dllimport) int TGAtoACE(
		char * infile, 			// TGA file
                DWORD TextureFormat, 		// list below (DXT1 or DXT1a only!)
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                char*fname);			// output ACE filename

extern "C" __declspec(dllimport) int TGAtoDDS(
		char * infile, 			// TGA file
                DWORD TextureFormat, 		// list below (DXT1 or DXT1a only!)
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                char*fname);			// output DDS filename

extern "C" __declspec(dllimport) int TGAtoBMP(
		char * infile, 			// TGA file
                DWORD TextureFormat, 		// list below (DXT1 or DXT1a only!)
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                char*fname);			// output DDS filename

extern "C" __declspec(dllimport) int TGAtoBMPS(
		char * infile, 			// TGA file
		char* imagefile,		// 24 bit image output
                char* alphafile);		// 8 bit alpha output

extern "C" __declspec(dllimport) int BMPStoTGA(
		char* imagefile,		// 24 bit image bmp input
                char* alphafile,		// 8 bit alpha bmp input
		char* outfoile);		// Targa file for output

enum TextureFormats
{
    kDXT1 ,
    kDXT1a ,  // DXT1 with one bit alpha
    kDXT3 ,   // explicit alpha
    kDXT5 ,   // interpolated alpha
    k4444 ,   // a4 r4 g4 b4
    k1555 ,   // a1 r5 g5 b5
    k565 ,    // a0 r5 g6 b5
    k8888 ,   // a8 r8 g8 b8
    k888 ,    // a0 r8 g8 b8
    k555 ,    // a0 r5 g5 b5
    k8   ,   // paletted
    kV8U8 ,   // DuDv 
    kCxV8U8 ,   // normal map
    kA8 ,            // alpha only
    k4  ,            // 16 bit color      
    kQ8W8V8U8,
    kA8L8,
    kTextureFormatLast
};

// TextureFormat (dll will translate to the correct k)
#define TF_DXT1            10
#define TF_DXT1_1BitAlpha  11
#define TF_DXT3            12
#define TF_DXT5            13
#define TF_RGB4444         14
#define TF_RGB1555         15
#define TF_RGB565          16
#define TF_RGB8888         17
#define TF_RGB888          18
#define TF_RGB555          19
#define TF_8Bit            20


#define DXTERR_INPUT_POINTER_ZERO -1
#define DXTERR_DEPTH_IS_NOT_3_OR_4 -2
#define DXTERR_NON_POWER_2 -3

#endif



