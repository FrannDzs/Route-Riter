// ace2bmps.cpp : Defines the entry point for the console application.
//

#include <string.h>
#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include "mwdds.h"


char*tex=
        "DDS2TGA <infile> <outtga>>\n"
        "This program uses mwace.dll to convert\n"
        "DDS Image files to Targa format\n"
        ;

int main(int argc, char* argv[])
{
int result=0;

    if(argc!=3)
    {
		printf(tex);
        return 0;
    }
   		result=DDStoTGA(argv[1],argv[2]);
		//result=TGAtoACE(argv[1],TF_DXT1,1,0,argv[2]);
    return result;

}
