// ace2bmps.cpp : Defines the entry point for the console application.
//

#include <string.h>
#include "stdafx.h"
#include <windows.h>
#include <stdio.h>



char*tex=
        "DDS2TGA <infile> <outtga>\n"
        "This program uses mwdds.dll to convert\n"
        "DDS Image files to Targa format\n"
        ;


typedef int (*MYPROC)(char*,char*);

int main(int argc, char* argv[])
{
int result=0;
HINSTANCE mylib;
MYPROC myproc;


    if(argc!=3)
    {
		printf(tex);
        return 0;
    }
	mylib=LoadLibrary("mwdds");
    if(mylib)
    {
		myproc=(MYPROC)GetProcAddress(mylib,"DDStoTGA");
		if(myproc )	result=(*myproc)(argv[1],argv[2]);
			
		else printf("Unable to access DLL functions\n");
		
		FreeLibrary(mylib);
	}
	else printf("Unable to open DLL\n");

   return result;

}
