//---------------------------------------------------------------------------
#include <vcl\condefs.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#pragma hdrstop

#include "mwdds.h"
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
typedef int (*MYPROC)(char*,DWORD,bool,bool,char*);
char*tex=
        "TGA2DDS <intga> <outdds>\n"
        "This program uses mwdds.dll to convert any\n"
        "Targa Image files to DDS DXT3\n"
        ;

//---------------------------------------------------------------------------
int main(int argc, char **argv)
{
int result=0;
HINSTANCE mylib;
MYPROC myproc;

        if(argc!=3)
                {
                printf(tex);
                return 0;
                }
       mylib=LoadLibrary("mwdds");
       if(mylib)
                {
                myproc= (MYPROC)GetProcAddress(mylib,"TGAcompressDDS");
                if(myproc)
                        {
                        result=(*myproc)(argv[1],TF_DXT3,true,false,argv[2]);
                        if(result)printf("converted....\n");
                        }
                else printf("Unable to load function\n");
                FreeLibrary(mylib);
                }
       else printf("Unable to load dll\n");
       return result;
}
//---------------------------------------------------------------------------

