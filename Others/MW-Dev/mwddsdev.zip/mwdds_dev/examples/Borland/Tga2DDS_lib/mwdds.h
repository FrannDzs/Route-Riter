/*=========================================================
	
	Header file for MWDDS.DLL

	copyright (c) 2002-2003 Martin Wright

==========================================================*/	

#ifndef MWDDS
#define MWDDS

#define FILTER_BOX 133
#define FILTER_CUBIC 134
#define FILTER_FULLDFT 135
#define FILTER_KAISER 136
#define FILTER_LINEAR_LIGHT_KAISER 137

#ifndef _MSC_VER
//LinkLib Aliasing for Borland
#define _DXTSetMipFilter	DXTSetMipFilter
#define _DXTcompress		DXTcompress
#define _DXTcreateMIPS		DXTcreateMIPS
#define _DXTcompressACE		DXTcompressACE
#define _TGAcompressBMP		TGAcompressBMP
#define _TGAcompressDDS		TGAcompressDDS
#define _BMPScompressBMP	BMPScompressBMP
#define _CombineAlphaDXT1	CombineAlphaDXT1
#define _DDStoTGA		DDStoTGA
#endif

extern "C" __declspec(dllimport) int  DXTSetMipFilter(short typ);

extern "C" __declspec(dllimport) int  DXTcompress(
		unsigned char * raw_data, 	// pointer to data (24 or 32 bit)
                unsigned long w, 		// width in texels
                unsigned long h, 		// height in texels
                DWORD TextureFormat, 		// list below
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                DWORD depth, 			// 3 or 4
                void* callback,			// callback function
                char* fname);  			// output DDS filename

extern "C" __declspec(dllimport) int  DXTcompressBMP(
		unsigned char * raw_data, 	// pointer to data (24 or 32 bit)
                unsigned long w, 		// width in texels
                unsigned long h, 		// height in texels
                DWORD TextureFormat, 		// list below
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                DWORD depth, 			// 3 or 4
                char* fname); 			// output BMP filename 

extern "C" __declspec(dllimport) int  DXTcreateMIPS(
		unsigned char * raw_data, 	// pointer to data (24 or 32 bit)
                unsigned long w, 		// width in texels
                unsigned long h, 		// height in texels
                DWORD TextureFormat, 		// list below
                bool bDither,			// use dither for 16 bit
                DWORD depth, 			// 3 or 4
                char* fname);  			// basename for mip files

extern "C" __declspec(dllimport) int  DXTcompressACE(
		unsigned char * raw_data, 	// pointer to data (24 or 32 bit)
                unsigned long w, 		// width in texels
                unsigned long h, 		// height in texels
                DWORD TextureFormat, 		// list below (DXT1/DXT1a only)
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                DWORD depth, 			// 3 or 4
                char* fname);			// output ACE filename

extern "C" __declspec(dllimport) int TGAcompressBMP(
		char * infile, 			// TGA file
                DWORD TextureFormat, 		// list below
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                char*fname);			// output BMP filename

extern "C" __declspec(dllimport) int TGAcompressDDS(
		char * infile, 			// TGA file
                DWORD TextureFormat, 		// list below
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                char*fname);			// output DDS filename

extern "C" __declspec(dllimport) int BMPScompressBMP(
		char * infile, 			// 24 bit Bmp file
		char* alpha,			// 8 bit greyscale Alpha Bmp
                DWORD TextureFormat, 		// list below
                bool bGenMipMaps,    		// auto gen MIP maps
                bool bDither,			// use dither for 16 bit
                char*fname);			// output BMP filename

extern "C" __declspec(dllimport) int CombineAlphaDXT1(
		char * infile, 			// 24 bit Bmp file
		char* alpha,			// 8 bit greyscale Alpha Bmp
                char*fname);			// output BMP filename

extern "C" __declspec(dllimport) int DDStoTGA(
		char * infile, 			// DDS file
		char*fname);   			// output targa filename


// TextureFormat
#define TF_DXT1            10
#define TF_DXT1_1BitAlpha  11
#define TF_DXT3            12
#define TF_DXT5            13
#define TF_RGB4444         14
#define TF_RGB1555         15
#define TF_RGB565          16
#define TF_RGB8888         17


#define DXTERR_INPUT_POINTER_ZERO -1
#define DXTERR_DEPTH_IS_NOT_3_OR_4 -2
#define DXTERR_NON_POWER_2 -3

#endif



