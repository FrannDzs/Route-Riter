//---------------------------------------------------------------------------
#include <vcl\condefs.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#pragma hdrstop

#include <mem.h>
#include "mwdds.h"
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
USELIB("mwddsbor.lib");
//---------------------------------------------------------------------------
char*tex=
        "Tga2DDS <intga> <outdds>\n"
        "This program uses mwds.dll to convert any\n"
        "32 bit TGA Image files to DDS DXT3\n"
        ;

//---------------------------------------------------------------------------
int main(int argc, char* argv[])
{
int result=0;
    if(argc!=3)
    {
		printf(tex);
        return 0;
    }
    printf("Converting %s\n",argv[1]);
    printf("to %s\n",argv[2]);
    printf("Note that the DDS image will be upside down\n");
    result=TGAcompressDDS(argv[1],TF_DXT3,true,false,argv[2]);
    printf("Done...\n");
    return result;

}

//---------------------------------------------------------------------------
