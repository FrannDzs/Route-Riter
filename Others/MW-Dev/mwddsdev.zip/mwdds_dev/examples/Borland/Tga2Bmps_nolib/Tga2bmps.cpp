//---------------------------------------------------------------------------
#include <vcl\condefs.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#pragma hdrstop

#include "mwdds.h"
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
typedef int (*MYPROC)(char*,char*,char*);
char*tex=
        "TGA2BMPS <intga> <outimage> <outalpha>\n"
        "This program uses mwdds.dll to convert any\n"
        "Targa Image files to 2 BMP files containing\n"
        "the image and alpha data seperately\n"
        ;

//---------------------------------------------------------------------------
int main(int argc, char **argv)
{
int result=0;
HINSTANCE mylib;
MYPROC myproc;

        if(argc!=4)
                {
                printf(tex);
                return 0;
                }
       mylib=LoadLibrary("mwdds");
       if(mylib)
                {
                myproc= (MYPROC)GetProcAddress(mylib,"TGAtoBMPS");
                if(myproc)
                        {
                        result=(*myproc)(argv[1],argv[2],argv[3]);
                        if(result)printf("converted....\n");
                        }
                else printf("Unable to load function\n");
                FreeLibrary(mylib);
                }
       else printf("Unable to load dll\n");
       return result;
}
//---------------------------------------------------------------------------

