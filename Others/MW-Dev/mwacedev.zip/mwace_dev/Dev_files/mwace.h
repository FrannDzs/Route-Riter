//header file for C programs using mwace.dll
#ifndef MWACE_H
#define MWACE_H
/*==============================================================================
MODULE:     MWACE.DLL
PURPOSE:    Functions to allow the conversion from the Train simulator
            ACE format to standard Bmp or Targa images.
READS:      All ACE formats including compressed and DXT1 formats.
            Alpha is preserved when converting to Targa.
            Alpha can be written as a seperate file when converting to Bmp
WRITES:     Standard Bmp format (24 bit for image, 8 bit for Alpha)
            Standard Targa format 32 bit
            Standard Bitmap to supplied memory buffer
==============================================================================*/
#include <stdio.h>
#ifndef PIC_H
struct Pic
{
	long width;	
    long height;
    long depth;
    long numcols;
    FILE* fin;
    char comment[80];
    unsigned char cmap[768];
    void* jlib;
    void* tlib;
    void* plib;
    unsigned char*buff;
    FILE* fout;
    void *ptr;
	void(*progress)(int,int);
	void* ilib;
	long stype;
	unsigned char spare[120];
};
#endif
//if MS VC++ then link library contains the function calling code
//For Borland call the DLL directly
#ifdef _MSC_VER
#define MWGFXFUNC extern "C"
#else
#define MWGFXFUNC extern "C" __declspec(dllimport)
#endif

//access to mwace.dll functions

MWGFXFUNC int AceToBmps(char*,char*,char*);
MWGFXFUNC int AceToBmp(char*,char*);
MWGFXFUNC int AceToTga(char*,char*);
MWGFXFUNC int AceToTgaSquare(char*,char*);
MWGFXFUNC int BmpsToTga(char*,char*,char*);
MWGFXFUNC int BmpsToTgaSquare(char*,char*,char*);
MWGFXFUNC int CheckAce(char*,struct Pic*);
MWGFXFUNC long AceInitLoad(char*);
MWGFXFUNC int AceLoadBitmap(char*,unsigned char*);
MWGFXFUNC int AceCompress(char*,char*);
MWGFXFUNC int AceDecompress(char*,char*);
MWGFXFUNC int AceCompressAll(char*,char*);

//AceCompress and AceDecompress return values
#define ACE_COMP_SUCCESS     	0		//file successfully compressed or decompressed
#define ACE_COMP_ISCOMPRESSED	1		//file already compressed so cannot be compressed
#define ACE_COMP_ISDXT		    2		//file is in DXT1 format and cannot be compressed
#define ACE_COMP_ISBIGGER	    3		//file cannot be compressed smaller than the original
#define ACE_COMP_NOTACE         4       //file is not an ACE file
#define ACE_COMP_NOMEMORY       5       //not enough memory to compress or decompress the file
#define ACE_COMP_NOSOURCE       6       //unable to open the source file
#define ACE_COMP_NODESTINATION  7       //unable to open the output file
#define ACE_COMP_PROBLEM        8       //unable to decompress the data (corrupted?)
#define ACE_COMP_NOTCOMPRESSED  9       //file not compressed so cannot decompress
#endif



