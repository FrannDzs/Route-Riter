//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "Unit1.h"

#include "mwace.h"

//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;

AnsiString tempimage = "C:\\tempace.bmp";
AnsiString tempalpha = "C:\\tempace1.bmp";

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Exit1Click(TObject *Sender)
{
remove(tempimage.c_str());
remove(tempalpha.c_str());
Close();    
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Open1Click(TObject *Sender)
{
if(OpenDialog1->Execute())
    {
    OpenDialog1->InitialDir=ExtractFilePath(OpenDialog1->FileName);
    AceToBmps( OpenDialog1->FileName.c_str(),tempimage.c_str(),tempalpha.c_str());
    Image1->Picture->LoadFromFile(tempimage);
    Image2->Picture->LoadFromFile(tempalpha);
    }

}
//---------------------------------------------------------------------------