//header file for C programs using mwace.dll
#ifndef MWACE_H
#define MWACE_H
/*==============================================================================
MODULE:     MWACE.DLL
PURPOSE:    Functions to allow the conversion from the Train simulator
            ACE format to standard Bmp or Targa images.
READS:      All ACE formats including compressed and DXT1 formats.
            Alpha is preserved when converting to Targa.
            Alpha can be written as a seperate file when converting to Bmp
WRITES:     Standard Bmp format (24 bit for image, 8 bit for Alpha)
            Standard Targa format 32 bit
            Standard Bitmap to supplied memory buffer
==============================================================================*/
struct Pic
{
	long width;	
    long height;
    long depth;
    long numcols;
    FILE* fin;
    char comment[80];
    unsigned char cmap[768];
    void* jlib;
    void* tlib;
    void* plib;
    unsigned char*buff;
    FILE* fout;
    void *ptr;
	void(*progress)(int,int);
	void* ilib;
	long stype;
	unsigned char spare[120];
};

#ifdef _MSC_VER
//LinkLib Aliasing for MS VC++
#define AceToBmps      _AceToBmps
#define AceToBmp       _AceToBmp
#define AceToTga       _AceToTga
#define AceToTgaSquare _AceToTgaSquare
#define CheckAce       _CheckAce
#define BmpsToTga      _BmpsToTga
#define BmpsToTgaSquare _BmpsToTgaSquare
#define AceInitLoad     _AceInitLoad
#define AceLoadBitmap   _AceLoadBitmap
#endif

//access to mwace.dll functions

extern "C" __declspec(dllimport) int  AceToBmps(char*inace,char*outimage,char*outalpha);
extern "C" __declspec(dllimport) int  AceToBmp(char*inace,char*outimage);
extern "C" __declspec(dllimport) int  AceToTga(char*inace,char*outtga);
extern "C" __declspec(dllimport) int  AceToTgaSquare(char*inace,char*outtga);
extern "C" __declspec(dllimport) int  BmpsToTga(char*image,char*alpha,char*outtga);
extern "C" __declspec(dllimport) int  BmpsToTgaSquare(char*image,char*alpha,char*outtga);
extern "C" __declspec(dllimport) int  CheckAce(char*inace,struct Pic*);
extern "C" __declspec(dllimport) unsigned long  AceInitLoad(char*inace);
extern "C" __declspec(dllimport) int  AceLoadBitmap(char*inace,unsigned char*buffer);
#endif



