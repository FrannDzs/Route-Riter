//---------------------------------------------------------------------------
#include <vcl\condefs.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#pragma hdrstop

#include <mem.h>
#include "mwace.h"
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
USELIB("mwace.lib");
//---------------------------------------------------------------------------
char*tex=
        "Ace2Tga <infile> <outtga>\n"
        "This program uses mwace.dll to convert any\n"
        "ACE Image files to Standard Targa format\n"
        ;
struct Pic pic;
//---------------------------------------------------------------------------
int main(int argc, char* argv[])
{
int result=0;
    if(argc!=3)
    {
		printf(tex);
        return 0;
    }
    memset(&pic,0,sizeof(struct Pic));
	result=CheckAce(argv[1],&pic);
	if(result)
	{
		printf("File   : %s\n",argv[1]);
        printf("Type   : %s\n",pic.comment);
        printf("Width  : %d\n",pic.width);
        printf("Height : %d\n",pic.height);
   		result=AceToTga(argv[1],argv[2]);
	}
    return result;

}

//---------------------------------------------------------------------------
