//---------------------------------------------------------------------------
#include <vcl\condefs.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#pragma hdrstop

//#include "mwace.h"
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
typedef int (*MYPROC)(char*,char*);
char*tex=
        "Ace2Tga <infile> <outtga>\n"
        "This program uses mwace.dll to convert any\n"
        "ACE Image files to Standard Targa format\n"
        ;
//struct Pic pic;
//---------------------------------------------------------------------------
int main(int argc, char **argv)
{
int result=0;
HINSTANCE mylib;
MYPROC myproc;

        if(argc!=3)
                {
                printf(tex);
                return 0;
                }
       mylib=LoadLibrary("mwace");
       if(mylib)
                {
                myproc= (MYPROC)GetProcAddress(mylib,"_AceToTga");
                if(myproc)
                        {
                        result=(*myproc)(argv[1],argv[2]);
                        if(result)printf("converted....\n");
                        }
                else printf("Unable to load function\n");
                FreeLibrary(mylib);
                }
       else printf("Unable to load mwace.dll\n");
       return result;
}
//---------------------------------------------------------------------------
