// PicViewView.cpp : implementation of the CPicViewView class
//

#include "stdafx.h"
#include "PicView.h"

#include "PicViewDoc.h"
#include "PicViewView.h"
#include "mwace.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPicViewView

IMPLEMENT_DYNCREATE(CPicViewView, CView)

BEGIN_MESSAGE_MAP(CPicViewView, CView)
	//{{AFX_MSG_MAP(CPicViewView)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPicViewView construction/destruction

CPicViewView::CPicViewView()
{
	// TODO: add construction code here

}

CPicViewView::~CPicViewView()
{
}

BOOL CPicViewView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPicViewView drawing

void CPicViewView::OnDraw(CDC* pDC)
{
	CPicViewDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	RECT Rect;
	GetClientRect( &Rect );
	mypic.SetPalette( pDC );
	mypic.Draw( pDC, 0, 0,
		Rect.right, Rect.bottom );
}

/////////////////////////////////////////////////////////////////////////////
// CPicViewView diagnostics

#ifdef _DEBUG
void CPicViewView::AssertValid() const
{
	CView::AssertValid();
}

void CPicViewView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPicViewDoc* CPicViewView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPicViewDoc)));
	return (CPicViewDoc*)m_pDocument;
}
#endif //_DEBUG

void CPicViewView::OnFileOpen() 
{
	// TODO: Add your command handler code here
	static char szFilter[] = "ACE Image Files(*.ACE)|*.ACE||";
	char imagefile[256];
	struct Pic pic;
	
	//clear the Pic struct
	ZeroMemory( &pic, sizeof(struct Pic) );
	
	//call the "Open" dialog
	CFileDialog FileDlg( TRUE, NULL, NULL,OFN_HIDEREADONLY, szFilter );

	if( FileDlg.DoModal() == IDOK)
		{
		//get the selected filename as a null terminated string
		sprintf(imagefile,"%s",FileDlg.GetPathName());
		
		//use the CPic Class to convert and load the image
		mypic.Load( imagefile,&pic );
		
		//Check the source image to get image details
		CheckAce(imagefile,&pic);

		//update the status bar with image details
		CMainFrame*pFrame = (CMainFrame*)AfxGetApp()->m_pMainWnd;
		CStatusBar*pBar   = &pFrame->m_wndStatusBar;
		pBar->SetPaneText(0,pic.comment,true);
		
		InvalidateRect( NULL, TRUE );
		UpdateWindow();
		}
	
	
}
