// PicViewView.h : interface of the CPicViewView class
//
/////////////////////////////////////////////////////////////////////////////

#include "cpic.h"
#include "MainFrm.h"

#if !defined(AFX_PICVIEWVIEW_H__76D089A2_3EAB_4F96_98D6_0372474CDFD1__INCLUDED_)
#define AFX_PICVIEWVIEW_H__76D089A2_3EAB_4F96_98D6_0372474CDFD1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPicViewView : public CView
{
protected: // create from serialization only
	CPicViewView();
	DECLARE_DYNCREATE(CPicViewView)

// Attributes
public:
	CPicViewDoc* GetDocument();
	CPic mypic;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPicViewView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPicViewView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPicViewView)
	afx_msg void OnFileOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in PicViewView.cpp
inline CPicViewDoc* CPicViewView::GetDocument()
   { return (CPicViewDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICVIEWVIEW_H__76D089A2_3EAB_4F96_98D6_0372474CDFD1__INCLUDED_)
