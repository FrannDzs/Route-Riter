// ace2bmps.cpp : Defines the entry point for the console application.
//

#include <string.h>
#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include "mwace.h"


char*tex=
        "Ace2Bmps <infile> <outbmp> <outalpha>\n"
        "This program uses mwace.dll to convert\n"
        "Ace Image files to Standard BMP format\n"
        ;
struct Pic pic;

int main(int argc, char* argv[])
{
int result=0;

    if(argc!=4)
    {
		printf(tex);
        return 0;
    }
	result=CheckAce(argv[1],&pic);
	
//result=CheckAce("test.ace",&pic);
	if(result)
	{
		printf("File   : %s\n",argv[1]);
        printf("Type   : %s\n",pic.comment);
        printf("Width  : %d\n",pic.width);
        printf("Height : %d\n",pic.height);
   		result=AceToBmps(argv[1],argv[2],argv[3]);
	}
    return result;

}
