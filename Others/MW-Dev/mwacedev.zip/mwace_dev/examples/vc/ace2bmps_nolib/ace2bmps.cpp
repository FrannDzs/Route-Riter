// ace2bmps.cpp : Defines the entry point for the console application.
//

#include <string.h>
#include "stdafx.h"
#include <windows.h>
#include "mwace.h"


char*tex=
        "Ace2Bmp2 <infile> <outbmp> <outalpha>\n"
        "This program uses mwace.dll to convert\n"
        "Ace Image files to Standard BMP format\n"
        ;
struct Pic pic;

typedef int (*MYPROC)(char*,char*,char*);
typedef int (*MYCHECK)(char*,struct Pic*);

int main(int argc, char* argv[])
{
int result=0;
HINSTANCE mylib;
MYPROC myproc;
MYCHECK mycheck;


    if(argc!=4)
    {
		printf(tex);
        return 0;
    }
	mylib=LoadLibrary("mwace");
    if(mylib)
    {
		myproc=(MYPROC)GetProcAddress(mylib,"_AceToBmps");
		mycheck=(MYCHECK)GetProcAddress(mylib,"_CheckAce");
		if(myproc && mycheck)
		{
			result= (*mycheck)(argv[1],&pic);
			if(result)
			{
				printf("File   : %s\n",argv[1]);
				printf("Type   : %s\n",pic.comment);
				printf("Width  : %d\n",pic.width);
				printf("Height : %d\n",pic.height);
				printf("Output : %s\n",argv[2]);
				printf("Format : Windows Bitmap\n");
				printf("Depth  : %d bit\n",pic.depth);
				printf("Colours: %d\n",pic.numcols);
				result=(*myproc)(argv[1],argv[2],argv[3]);
			}
		else printf("Unable to access DLL functions\n");
		}
		FreeLibrary(mylib);
	}
	else printf("Unable to open DLL\n");

   return result;

}
