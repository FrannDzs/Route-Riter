/****************************************************************************/
/* SFTTABS 2.0 - Tab Custom Control for Windows                             */
/* Copyright (C) 1994, 1995  Softel vdm. All Rights Reserved.               */
/****************************************************************************/

/* Tabs Control */

#if !defined(_INC_SFTTABS_2)
#define _INC_SFTTABS_2                              /* only include once */

#define SFTTABS_CLASS32             "KLTabControl"          /* Tab Control Window Class WIN32 */
#define SFTTABS_CLASS16             "KLTabControl"          /* Tab Control Window Class WIN16 */
#define SFTTABS_GRAYDIALOGCLASS32   "SoftelGrayDialog32"    /* Gray background for dialogs WIN32 */
#define SFTTABS_GRAYDIALOGCLASS16   "SoftelGrayDialog"      /* Gray background for dialogs WIN16 */

#define SFTTABS_CLASS               SFTTABS_CLASS32         /* Tab Control Window Class WIN32 */
#define SFTTABS_GRAYDIALOGCLASS     SFTTABS_GRAYDIALOGCLASS32/* Gray background for dialogs */

#define SFTTABS_MAXROWS      16                     /* max. # of tab rows */    
#define SFTTABS_MAXTABS     128                     /* max. # of tabs */

/* Tabs Control Styles */

#define SFTTABSSTYLE_FIRSTSTYLE                 0
#define SFTTABSSTYLE_STANDARD                   0L  /* Standard style */
#define SFTTABSSTYLE_STANDARD_LEFT              1L  /* Standard style, left */
#define SFTTABSSTYLE_STANDARD_LEFT_V            2L  /* Standard style, left, vertical */
#define SFTTABSSTYLE_STANDARD_RIGHT             3L  /* Standard style, right */
#define SFTTABSSTYLE_STANDARD_RIGHT_V           4L  /* Standard style, right, vertical */
#define SFTTABSSTYLE_STANDARD_BOTTOM            5L  /* Standard style, bottom */
#define SFTTABSSTYLE_STANDARD_II                6L  /* Standard style II */
#define SFTTABSSTYLE_STANDARD_II_LEFT           7L  /* Standard style II, left */
#define SFTTABSSTYLE_STANDARD_II_LEFT_V         8L  /* Standard style II, left, vertical */
#define SFTTABSSTYLE_STANDARD_II_RIGHT          9L  /* Standard style II, right */
#define SFTTABSSTYLE_STANDARD_II_RIGHT_V       10L  /* Standard style II, right, vertical */
#define SFTTABSSTYLE_STANDARD_II_BOTTOM        11L  /* Standard style II, bottom */
#define SFTTABSSTYLE_WIZARD                    12L  /* Wizard style */
#define SFTTABSSTYLE_SIMPLE                    13L  /* Simple, top */
#define SFTTABSSTYLE_SIMPLE_BOTTOM             14L  /* Simple, bottom */
#define SFTTABSSTYLE_SPIRAL_BOTTOM             15L  /* Spiral notebook, bottom */
#define SFTTABSSTYLE_SPIRAL_RIGHT              16L  /* Spiral notebook, right */
#define SFTTABSSTYLE_SPIRAL_RIGHT_V            17L  /* Spiral notebook, right, vertical */
#define SFTTABSSTYLE_3RING_BOTTOM              18L  /* 3Ring notebook, bottom */
#define SFTTABSSTYLE_3RING_RIGHT               19L  /* 3Ring notebook, right */
#define SFTTABSSTYLE_3RING_RIGHT_V             20L  /* 3Ring notebook, right, vertical */
#define SFTTABSSTYLE_MODERN_I                  21L  /* Modern style I */
#define SFTTABSSTYLE_MODERN_I_LEFT_V           22L  /* Modern style I, left, vertical */
#define SFTTABSSTYLE_MODERN_I_RIGHT_V          23L  /* Modern style I, right, vertical */
#define SFTTABSSTYLE_MODERN_I_BOTTOM           24L  /* Modern style I, bottom, vertical */
#define SFTTABSSTYLE_LASTSTYLE                 24L
#define SFTTABSSTYLE_MASK                  0x00ffL  /* to uncover style # */

#define SFTTABSSTYLE_MULTILINE             0x0100L  /* Multiline tab labels can be defined */
#define SFTTABSSTYLE_SCROLLABLE            0x0200L  /* scrollable tabs can be defined */
#define SFTTABSSTYLE_MARGIN                0x0400L  /* Margin can be defined */
#define SFTTABSSTYLE_MULTIROW              0x0800L  /* Multiple tab rows can be defined */
#define SFTTABSSTYLE_HORIZONTAL            0x1000L  /* Basic tab layout is horizontal (vertical otherwise) */
#define SFTTABSSTYLE_CLIENTAREA            0x2000L  /* Clientarea can be defined */

#if !defined(RC_INVOKED)

#if defined(__cplusplus)
extern "C" {
 #define SFTSEND ::SendMessage
 #ifdef _WIN64
  #define SFTGWLNG ::GetWindowLongPtr
 #else
  #define SFTGWLNG ::GetWindowLong
 #endif
#else
 #define SFTSEND SendMessage
 #ifdef _WIN64
  #define SFTGWLNG GetWindowLongPtr
 #else
  #define SFTGWLNG GetWindowLong
 #endif
#endif

/* Tabs Control Notification */

#define SFTTABSN_KILLFOCUS              2           /* Lost focus */
#define SFTTABSN_SETFOCUS               3           /* Got Focus */

#define SFTTABSN_SWITCHING              4           /* About to switch to another tab */  
#define SFTTABSN_SWITCHED               5           /* Done switching to another tab */  
#define SFTTABSN_SCROLLED               6           /* Done scrolling */
#define SFTTABSN_MOUSEMOVE              7           /* WM_MOUSEMOVE received */
#define SFTTABSN_SIZECHANGED            8           /* WM_SIZE received */

#define SFTTABSN_LBUTTONDOWN            10          /* Left mouse button pressed (not on a tab) */
#define SFTTABSN_LBUTTONDBLCLK          11          /* Left mouse button double-clicked (not on a tab) */
#define SFTTABSN_MBUTTONDOWN            12          /* Middle mouse button pressed */
#define SFTTABSN_MBUTTONDBLCLK          13          /* Middle mouse button double-clicked */
#define SFTTABSN_RBUTTONDOWN            14          /* Right mouse button pressed */
#define SFTTABSN_RBUTTONDBLCLK          15          /* Right mouse button double-clicked */

/* Misc. definitions for message parameter ids */

/* Messages */

#define SFTTABSM_ADDTAB_A       (WM_USER+10)        /* Add a tab (ANSI string) */
#define SFTTABSM_ADDTAB_W       (WM_USER+11)        /* Add a tab (UNICODE string) */
#define SFTTABSM_ADJUSTCLIENTRECT \
                                (WM_USER+12)        /* Calculate tab control size */
#define SFTTABSM_DELETETAB      (WM_USER+13)        /* Delete a tab */
#define SFTTABSM_GETCONTROLINFO (WM_USER+14)        /* Get tab control information */
#define SFTTABSM_GETCURRENTTAB  (WM_USER+15)        /* Get current tab index */
#define SFTTABSM_GETTABINFO     (WM_USER+16)        /* Get tab information */
#define SFTTABSM_GETTABLABEL_A  (WM_USER+17)        /* Get tab label (ANSI string) */
#define SFTTABSM_GETTABLABEL_W  (WM_USER+18)        /* Get tab label (UNICODE string) */
#define SFTTABSM_GETTABLABELLEN (WM_USER+19)        /* Get tab label length */
#define SFTTABSM_INSERTTAB_A    (WM_USER+20)        /* Insert a tab (ANSI string) */
#define SFTTABSM_INSERTTAB_W    (WM_USER+21)        /* Insert a tab (UNICODE string) */
#define SFTTABSM_QUERYCHAR_A    (WM_USER+22)        /* Query if tab control handles character (ANSI) */
#define SFTTABSM_QUERYCHAR_W    (WM_USER+23)        /* Query if tab control handles character (UNICODE) */
#define SFTTABSM_RESETCONTENT   (WM_USER+24)        /* Delete all tabs */
#define SFTTABSM_SCROLLTABS     (WM_USER+25)        /* Scroll tabs */
#define SFTTABSM_SETCONTROLINFO (WM_USER+26)        /* Set tab control information */
#define SFTTABSM_SETCURRENTTAB  (WM_USER+27)        /* Set current tab index */
#define SFTTABSM_SETTABINFO     (WM_USER+28)        /* Set tab information */
#define SFTTABSM_SETTABLABEL_A  (WM_USER+29)        /* Set tab label (ANSI string) */
#define SFTTABSM_SETTABLABEL_W  (WM_USER+30)        /* Set tab label (UNICODE string) */

#if defined(UNICODE)|| defined(_UNICODE)
#define SFTTABSM_ADDTAB         SFTTABSM_ADDTAB_W
#define SFTTABSM_INSERTTAB      SFTTABSM_INSERTTAB_W
#define SFTTABSM_GETTABLABEL    SFTTABSM_GETTABLABEL_W
#define SFTTABSM_QUERYCHAR      SFTTABSM_QUERYCHAR_W
#define SFTTABSM_SETTABLABEL    SFTTABSM_SETTABLABEL_W
#else
#define SFTTABSM_ADDTAB         SFTTABSM_ADDTAB_A
#define SFTTABSM_INSERTTAB      SFTTABSM_INSERTTAB_A
#define SFTTABSM_GETTABLABEL    SFTTABSM_GETTABLABEL_A
#define SFTTABSM_QUERYCHAR      SFTTABSM_QUERYCHAR_A
#define SFTTABSM_SETTABLABEL    SFTTABSM_SETTABLABEL_A
#endif

/* Picture locations */

#define SFTTABS_GRAPH_NONE          0
#define SFTTABS_LEFTVALIGN          1
#define SFTTABS_RIGHTVALIGN         2
#define SFTTABS_GRAPH_LEFTVALIGN    3
#define SFTTABS_GRAPH_RIGHTVALIGN   4    
#define SFTTABS_GRAPH_TOP           5
#define SFTTABS_GRAPH_BOTTOM        6
#define SFTTABS_GRAPH_LEFT          7
#define SFTTABS_GRAPH_RIGHT         8    

/* Picture type */

#define SFTTABS_GRAPH_ICON   1
#define SFTTABS_GRAPH_BITMAP 2

/* Color */

#define SFTTABS_NOCOLOR ((COLORREF)-1)

#if defined(_MSC_VER)
# pragma pack(1)                        /* Packing */
#endif
#if defined(__BORLANDC__)
# pragma option -a1
#endif

/* Style Table Entry */

typedef struct tagSftTabsStyleTableA {
    /* Notice, these strings are always ANSI strings */
    LPCSTR lpszDesc;                    /* Style description */
    LPCSTR lpszStyle;                   /* style ID */
    DWORD style;
    DWORD res1;
} SFTTABS_STYLETABLEA, FAR * LPSFTTABS_STYLETABLEA;

/* bitmap/icon structure */

typedef struct tagSftTabsGraph {
    WORD location;
    WORD type;
    union {
        HICON hIcon;
        HBITMAP hBitmap;
    } item;
} SFTTABS_GRAPH, FAR * LPSFTTABS_GRAPH;        
    
/* tab entry */

typedef struct tagSftTabsTab {
    /* modifiable fields */
    COLORREF colorBg, colorFg;          /* color */
    COLORREF colorBgSel, colorFgSel;
    SFTTABS_GRAPH graph;                /* graphics */
    BOOL fEnabled;                      /* enabled/disabled status */
    LPARAM userData;                    /* userdata */
    LPVOID lpTabData;                   /* reserved for C, C++ class implementation */
    HWND hwndSubDlg;                    /* reserved for C, C++ class implementation */

    DWORD res1, res2;    

    /* read/only information */
    int x, y;                           /* position (top left corner) */
    int cx, cy;                         /* width and height */
    int cxVis, cyVis;                   /* width and height of visible portion */

#if defined(UNICODE) || defined(_UNICODE)
    LPWSTR lpszText;                    /* label text */
#else
    LPSTR lpszText;                     /* label text */
#endif

    DWORD res10, res11;

} SFTTABS_TAB, FAR * LPSFTTABS_TAB;

typedef const SFTTABS_TAB FAR * LPCSFTTABS_TAB;

/* Control information */

typedef struct tagSftTabsControl {

    /* Modifiable fields */
    int style;                          /* tab style */
    int nRows;                          /* number of rows */
    int nRowTabs;                       /* number of tabs per row (if fFixed) */
    int leftMargin;                     /* width of left margin */
    int rightMargin;                    /* width of right margin */
    BOOL fFixed;                        /* same width for all tabs */
    BOOL fClientArea;                   /* Client area wanted */
    BOOL fMultiline;                    /* allow mulitline label text */
    BOOL fDialog;                       /* use with dialog */
    BOOL fTextOnly;                     /* use specified background color only for text */
    BOOL fScrollable;                   /* scrollable tabs */
    BOOL fHideScrollButtons;            /* hide scroll buttons */
    BOOL fBoldFont;                     /* use bold font for active tab */
    BOOL fFillComplete;                 /* fill rows completely */
    HBITMAP hButtonBitmap;              /* Scroll Button bitmap */
    LPVOID lpTabData;                   /* Data/Dialog associated with active tab */
    HWND hwndSubDlg;                    /* Subdialog associated with active tab */
    HWND hwndFrame;                     /* Frame, used as client area */    
    
    DWORD res1, res2, res3, res4, res5, res6;

    /* read/only fields */
    int nTabs;                          /* number of tabs */
    RECT ClientRect;                    /* Area useable by application */
    BOOL fLeftButton, fRightButton;     /* TRUE if scrolling in that direction possible (if fScrollable) */
    int visibleLeftTab;                 /* leftmost tab in first row (if fScrollable) */
    int naturalSize;                    /* Best height/width depending on tab style */

    DWORD res11, res12, res13, res14, res15, res16;

} SFTTABS_CONTROL, FAR * LPSFTTABS_CONTROL;

typedef const SFTTABS_CONTROL FAR * LPCSFTTABS_CONTROL;

#if defined(_MSC_VER)
# pragma pack()                         /* Packing */
#endif
#if defined(__BORLANDC__)
# pragma option -a-
#endif

typedef HWND (CALLBACK* SFTTABS_TABCALLBACK)(BOOL fCreate, HWND hwndOwner, HWND hwndPage, HWND hwndTab);

/* Functions */

BOOL WINAPI SftTabs_RegisterApp(HINSTANCE hInst);/* Call to use SftTabs with your application */
void WINAPI SftTabs_UnregisterApp(HINSTANCE hInst);/* Call to end using SftTabs with your application */
LPSFTTABS_STYLETABLEA WINAPI SftTabs_GetStyleTable(void);/* Returns available styles table */

void WINAPI SftTabs_SetPageActive(HWND hwndSubDlg, HWND hwndTab, LPVOID lpTabData);
void WINAPI SftTabs_SetPageInactive(HWND hwndTab);
BOOL WINAPI SftTabs_ActivatePage(HWND hwndParent, HWND hwndTabs, HWND hwndFrame, BOOL fInitializing);
BOOL WINAPI SftTabs_DeactivatePage(HWND hwndParent, HWND hwndTab);
BOOL WINAPI SftTabs_ClosePossible(HWND hwndParent, HWND hwndTab);
BOOL WINAPI SftTabs_Destroy(HWND hwndParent, HWND hwndTab);
BOOL WINAPI SftTabs_HandleDialogMessage(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL WINAPI SftTabs_HandleWindowMessage(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, LRESULT FAR* lplResult);
BOOL WINAPI SftTabs_HasControlParentSupport(void);
HWND WINAPI SftTabs_GetTabControlFromPage(HWND hwndPage);/* Get tab control associated with a page */
BOOL WINAPI SftTabs_IsTabControl(HWND hwndCtl);         /* Query if window is a tab control */
BOOL WINAPI SftTabs_IsTabControlWithDialog(HWND hwndCtl);/* Query if window is a tab control with attached dialog */
BOOL WINAPI SftTabs_IsRegisteredDialog(HWND hwndDialog);/* Query a top level dialog */
BOOL WINAPI SftTabs_RegisterDialog(HWND hwndDialog);    /* Register a top level dialog */
BOOL WINAPI SftTabs_UnregisterDialog(HWND hwndDialog);  /* Unregister a top level dialog */
#define SftTabs_IsRegisteredWindow SftTabs_IsRegisteredDialog /* Query a top level window */
#define SftTabs_RegisterWindow SftTabs_RegisterDialog   /* Register a top level dialog */
#define SftTabs_UnregisterWindow SftTabs_UnregisterDialog/* Unregister a top level dialog */


/* Bitmap location */
#define BMBUTTON_LEFT       1
#define BMBUTTON_RIGHT      2
#define BMBUTTON_TOP        3
#define BMBUTTON_BOTTOM     4
#define BMBUTTON_CENTER     5
/* Bitmap button support (INTERNAL USE ONLY) */
void WINAPI BitmapButton_OnDrawItem(HWND hwnd, const DRAWITEMSTRUCT FAR* lpDrawItem, HBITMAP hBitmap, int flag);
void WINAPI ChangeBitmapColor(HBITMAP hbmSrc, COLORREF rgbOld, COLORREF rgbNew);
void WINAPI MakeDisabledBitmap(HBITMAP hBitmap);
HBITMAP WINAPI CopyBitmap(HBITMAP hbmpSrc);

/* Message Crackers */

#if defined(_UNICODE) || defined(UNICODE)
/* int Cls_OnAddTab_W(HWND hwnd, LPCWSTR lpsz); */
#define HANDLE_SFTTABSM_ADDTAB_W(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPCWSTR)(lParam))
#define FORWARD_SFTTABSM_ADDTAB_W(hwnd, lpsz, fn) \
    (int)(fn)((hwnd), SFTTABSM_ADDTAB_W, 0, (LPARAM)(LPCWSTR)(lpsz))
#define SftTabs_AddTab_W(hwnd, lpsz) \
                                FORWARD_SFTTABSM_ADDTAB_W((hwnd), (lpsz), SFTSEND)
#define SftTabs_AddTab SftTabs_AddTab_W
#define FORWARD_SFTTABSM_ADDTAB FORWARD_SFTTABSM_ADDTAB_W
#else
#define SftTabs_AddTab SftTabs_AddTab_A
#define FORWARD_SFTTABSM_ADDTAB FORWARD_SFTTABSM_ADDTAB_A
#endif

/* int Cls_OnAddTab_A(HWND hwnd, LPCWSTR lpsz); */
#define HANDLE_SFTTABSM_ADDTAB_A(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPCSTR)(lParam))
#define FORWARD_SFTTABSM_ADDTAB_A(hwnd, lpsz, fn) \
    (int)(fn)((hwnd), SFTTABSM_ADDTAB_A, 0, (LPARAM)(LPCSTR)(lpsz))
#define SftTabs_AddTab_A(hwnd, lpsz) \
                                FORWARD_SFTTABSM_ADDTAB_A((hwnd), (lpsz), SFTSEND)

/* BOOL Cls_OnAdjustClientRect(HWND hwnd, LPRECT lpRect); */
#define HANDLE_SFTTABSM_ADJUSTCLIENTRECT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPRECT)(lParam))
#define FORWARD_SFTTABSM_ADJUSTCLIENTRECT(hwnd, lpRect, fn) \
    (BOOL)(fn)((hwnd), SFTTABSM_ADJUSTCLIENTRECT, 0, (LPARAM)(LPRECT)(lpRect))
#define SftTabs_AdjustClientRect(hwnd, lpRect) \
                                FORWARD_SFTTABSM_ADJUSTCLIENTRECT((hwnd), (lpRect), SFTSEND)

/* int Cls_OnDeleteTab(HWND hwnd, int iTab); */
#define HANDLE_SFTTABSM_DELETETAB(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam))
#define FORWARD_SFTTABSM_DELETETAB(hwnd, iTab, fn) \
    (int)(fn)((hwnd), SFTTABSM_DELETETAB, (WPARAM)(iTab), 0L)
#define SftTabs_DeleteTab(hwnd, iTab) \
                                FORWARD_SFTTABSM_DELETETAB((hwnd), (iTab), SFTSEND)

/* BOOL Cls_OnGetControlInfo(HWND hwnd, LPSFTTABS_CONTROL lpCtl); */
#define HANDLE_SFTTABSM_GETCONTROLINFO(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPSFTTABS_CONTROL)(lParam))
#define FORWARD_SFTTABSM_GETCONTROLINFO(hwnd, lpCtl, fn) \
    (BOOL)(fn)((hwnd), SFTTABSM_GETCONTROLINFO, 0, (LPARAM)(LPSFTTABS_CONTROL)(lpCtl))
#define SftTabs_GetControlInfo(hwnd, lpCtl) \
                                FORWARD_SFTTABSM_GETCONTROLINFO((hwnd), (lpCtl), SFTSEND)

/* int Cls_OnGetCurrentTab(HWND hwnd); */
#define HANDLE_SFTTABSM_GETCURRENTTAB(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTABSM_GETCURRENTTAB(hwnd, fn) \
    (int)(fn)((hwnd), SFTTABSM_GETCURRENTTAB, 0, 0)
#define SftTabs_GetCurrentTab(hwnd) \
                                FORWARD_SFTTABSM_GETCURRENTTAB((hwnd), SFTSEND)

/* BOOL Cls_OnGetTabInfo(HWND hwnd, int iTab, LPSFTTABS_TAB lpTab); */
#define HANDLE_SFTTABSM_GETTABINFO(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (LPSFTTABS_TAB)(lParam))
#define FORWARD_SFTTABSM_GETTABINFO(hwnd, iTab, lpTab, fn) \
    (BOOL)(fn)((hwnd), SFTTABSM_GETTABINFO, (WPARAM)(iTab), (LPARAM)(LPSFTTABS_TAB)(lpTab))
#define SftTabs_GetTabInfo(hwnd, iTab, lpTab) \
                                FORWARD_SFTTABSM_GETTABINFO((hwnd), (iTab), (lpTab), SFTSEND)

#if defined(_UNICODE) || defined(UNICODE)
/* int Cls_OnGetTabLabel_W(HWND hwnd, int iTab, LPWSTR lpsz); */
#define HANDLE_SFTTABSM_GETTABLABEL_W(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (LPWSTR)(lParam))
#define FORWARD_SFTTABSM_GETTABLABEL_W(hwnd, iTab, lpsz, fn) \
    (int)(fn)((hwnd), SFTTABSM_GETTABLABEL_W, (WPARAM)(iTab), (LPARAM)(LPWSTR)(lpsz))
#define SftTabs_GetTabLabel_W(hwnd, iTab, lpsz) \
                                FORWARD_SFTTABSM_GETTABLABEL_W((hwnd), (iTab), (lpsz), SFTSEND)
#define SftTabs_GetTabLabel SftTabs_GetTabLabel_W
#define FORWARD_SFTTABSM_GETTABLABEL FORWARD_SFTTABSM_GETTABLABEL_W
#else
#define SftTabs_GetTabLabel SftTabs_GetTabLabel_A
#define FORWARD_SFTTABSM_GETTABLABEL FORWARD_SFTTABSM_GETTABLABEL_A
#endif

/* int Cls_OnGetTabLabel_A(HWND hwnd, int iTab, LPSTR lpsz); */
#define HANDLE_SFTTABSM_GETTABLABEL_A(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (LPSTR)(lParam))
#define FORWARD_SFTTABSM_GETTABLABEL_A(hwnd, iTab, lpsz, fn) \
    (int)(fn)((hwnd), SFTTABSM_GETTABLABEL_A, (WPARAM)(iTab), (LPARAM)(LPSTR)(lpsz))
#define SftTabs_GetTabLabel_A(hwnd, iTab, lpsz) \
                                FORWARD_SFTTABSM_GETTABLABEL_A((hwnd), (iTab), (lpsz), SFTSEND)

/* int Cls_OnGetTabLabelLen(HWND hwnd, int iTab); */
#define HANDLE_SFTTABSM_GETTABLABELLEN(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam))
#define FORWARD_SFTTABSM_GETTABLABELLEN(hwnd, iTab, fn) \
    (int)(fn)((hwnd), SFTTABSM_GETTABLABELLEN, (WPARAM)(iTab), 0L)
#define SftTabs_GetTabLabelLen(hwnd, iTab) \
                                FORWARD_SFTTABSM_GETTABLABELLEN((hwnd), (iTab), SFTSEND)

#if defined(_UNICODE) || defined(UNICODE)
/* int Cls_OnInsertTab_W(HWND hwnd, int iTab, LPCWSTR lpsz); */
#define HANDLE_SFTTABSM_INSERTTAB_W(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (LPCWSTR)(lParam))
#define FORWARD_SFTTABSM_INSERTTAB_W(hwnd, iTab, lpsz, fn) \
    (int)(fn)((hwnd), SFTTABSM_INSERTTAB_W, (WPARAM)(iTab), (LPARAM)(LPCWSTR)(lpsz))
#define SftTabs_InsertTab_W(hwnd, iTab, lpsz) \
                                FORWARD_SFTTABSM_INSERTTAB_W((hwnd), (iTab), (lpsz), SFTSEND)
#define SftTabs_InsertTab SftTabs_InsertTab_W
#define FORWARD_SFTTABSM_INSERTTAB FORWARD_SFTTABSM_INSERTTAB_W
#else
#define SftTabs_InsertTab SftTabs_InsertTab_A
#define FORWARD_SFTTABSM_INSERTTAB FORWARD_SFTTABSM_INSERTTAB_A
#endif

/* int Cls_OnInsertTab_A(HWND hwnd, int iTab, LPCSTR lpsz); */
#define HANDLE_SFTTABSM_INSERTTAB_A(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (LPCSTR)(lParam))
#define FORWARD_SFTTABSM_INSERTTAB_A(hwnd, iTab, lpsz, fn) \
    (int)(fn)((hwnd), SFTTABSM_INSERTTAB_A, (WPARAM)(iTab), (LPARAM)(LPCSTR)(lpsz))
#define SftTabs_InsertTab_A(hwnd, iTab, lpsz) \
                                FORWARD_SFTTABSM_INSERTTAB_A((hwnd), (iTab), (lpsz), SFTSEND)

#if defined(_UNICODE) || defined(UNICODE)
/* BOOL Cls_OnQueryChar(HWND hwnd, WCHAR ch); */
#define HANDLE_SFTTABSM_QUERYCHAR_W(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (WCHAR)(wParam))
#define FORWARD_SFTTABSM_QUERYCHAR_W(hwnd, ch, fn) \
    (BOOL)(fn)((hwnd), SFTTABSM_QUERYCHAR, (WPARAM)(ch), 0L)
#define SftTabs_QueryChar_W(hwnd, ch) \
                                FORWARD_SFTTABSM_QUERYCHAR_W((hwnd), (ch), SFTSEND)
#define SftTabs_QueryChar SftTabs_QueryChar_W
#define FORWARD_SFTTABSM_QUERYCHAR FORWARD_SFTTABSM_QUERYCHAR_W
#else
#define SftTabs_QueryChar SftTabs_QueryChar_A
#define FORWARD_SFTTABSM_QUERYCHAR FORWARD_SFTTABSM_QUERYCHAR_A
#endif
/* BOOL Cls_OnQueryChar(HWND hwnd, int ch); */
#define HANDLE_SFTTABSM_QUERYCHAR_A(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam))
#define FORWARD_SFTTABSM_QUERYCHAR_A(hwnd, ch, fn) \
    (BOOL)(fn)((hwnd), SFTTABSM_QUERYCHAR_A, (WPARAM)(ch), 0L)
#define SftTabs_QueryChar_A(hwnd, ch) \
                                FORWARD_SFTTABSM_QUERYCHAR_A((hwnd), (ch), SFTSEND)

/* void Cls_OnResetContent(HWND hwnd); */
#define HANDLE_SFTTABSM_RESETCONTENT(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd)), 0L)
#define FORWARD_SFTTABSM_RESETCONTENT(hwnd, fn) \
    (void)(fn)((hwnd), SFTTABSM_RESETCONTENT, 0, 0L)
#define SftTabs_ResetContent(hwnd) \
                                FORWARD_SFTTABSM_RESETCONTENT((hwnd), SFTSEND)

/* int Cls_OnScrollTabs(HWND hwnd, BOOL fUpOrLeft); */
#define HANDLE_SFTTABSM_SCROLLTABS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (BOOL)(wParam))
#define FORWARD_SFTTABSM_SCROLLTABS(hwnd, fUpOrLeft, fn) \
    (int)(fn)((hwnd), SFTTABSM_SCROLLTABS, (WPARAM)(fUpOrLeft), 0L)
#define SftTabs_ScrollTabs(hwnd, fUpOrLeft) \
                                FORWARD_SFTTABSM_SCROLLTABS((hwnd), (fUpOrLeft), SFTSEND)

/* BOOL Cls_OnSetControlInfo(HWND hwnd, LPCSFTTABS_CONTROL lpCtl); */
#define HANDLE_SFTTABSM_SETCONTROLINFO(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPCSFTTABS_CONTROL)(lParam))
#define FORWARD_SFTTABSM_SETCONTROLINFO(hwnd, lpCtl, fn) \
    (BOOL)(fn)((hwnd), SFTTABSM_SETCONTROLINFO, 0, (LPARAM)(LPSFTTABS_CONTROL)(lpCtl))
#define SftTabs_SetControlInfo(hwnd, lpCtl) \
                                FORWARD_SFTTABSM_SETCONTROLINFO((hwnd), (lpCtl), SFTSEND)

/* int Cls_OnSetCurrentTab(HWND hwnd, int iTab); */
#define HANDLE_SFTTABSM_SETCURRENTTAB(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam))
#define FORWARD_SFTTABSM_SETCURRENTTAB(hwnd, iTab, fn) \
    (int)(fn)((hwnd), SFTTABSM_SETCURRENTTAB, (iTab), 0)
#define SftTabs_SetCurrentTab(hwnd, iTab) \
                                FORWARD_SFTTABSM_SETCURRENTTAB((hwnd), (iTab), SFTSEND)

/* BOOL Cls_OnSetTabInfo(HWND hwnd, int iTab, LPCSFTTABS_TAB lpTab); */
#define HANDLE_SFTTABSM_SETTABINFO(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (LPCSFTTABS_TAB)(lParam))
#define FORWARD_SFTTABSM_SETTABINFO(hwnd, iTab, lpTab, fn) \
    (BOOL)(fn)((hwnd), SFTTABSM_SETTABINFO, (WPARAM)(iTab), (LPARAM)(LPSFTTABS_TAB)(lpTab))
#define SftTabs_SetTabInfo(hwnd, iTab, lpTab) \
                                FORWARD_SFTTABSM_SETTABINFO((hwnd), (iTab), (lpTab), SFTSEND)

#if defined(_UNICODE) || defined(UNICODE)
/* BOOL Cls_OnSetTabLabel_W(HWND hwnd, int iTab, LPCWSTR lpsz); */
#define HANDLE_SFTTABSM_SETTABLABEL_W(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (LPCWSTR)(lParam))
#define FORWARD_SFTTABSM_SETTABLABEL_W(hwnd, iTab, lpsz, fn) \
    (BOOL)(fn)((hwnd), SFTTABSM_SETTABLABEL_W, (WPARAM)(iTab), (LPARAM)(LPCWSTR)(lpsz))
#define SftTabs_SetTabLabel_W(hwnd, iTab, lpsz) \
                                FORWARD_SFTTABSM_SETTABLABEL_W((hwnd), (iTab), (lpsz), SFTSEND)
#define SftTabs_SetTabLabel SftTabs_SetTabLabel_W
#define FORWARD_SFTTABSM_SETTABLABEL FORWARD_SFTTABSM_SETTABLABEL_W
#else
#define SftTabs_SetTabLabel SftTabs_SetTabLabel_A
#define FORWARD_SFTTABSM_SETTABLABEL FORWARD_SFTTABSM_SETTABLABEL_A
#endif

/* BOOL Cls_OnSetTabLabel_A(HWND hwnd, int iTab, LPCSTR lpsz); */
#define HANDLE_SFTTABSM_SETTABLABEL_A(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (LPCSTR)(lParam))
#define FORWARD_SFTTABSM_SETTABLABEL_A(hwnd, iTab, lpsz, fn) \
    (BOOL)(fn)((hwnd), SFTTABSM_SETTABLABEL_A, (WPARAM)(iTab), (LPARAM)(LPCSTR)(lpsz))
#define SftTabs_SetTabLabel_A(hwnd, iTab, lpsz) \
                                FORWARD_SFTTABSM_SETTABLABEL_A((hwnd), (iTab), (lpsz), SFTSEND)


#if defined(__cplusplus)
} /* extern "C" */
#endif


/* Microsoft Foundation Class Library Support */
/* Microsoft Foundation Class Library Support */
/* Microsoft Foundation Class Library Support */

#if defined(__AFX_H__) && defined(__cplusplus)

#include "SftTbM.H"                     /* SftTabs MFC Support */

#endif /* Microsoft Foundation Class Library Support */

/* ObjectWindows Library Support */
/* ObjectWindows Library Support */
/* ObjectWindows Library Support */

#if defined(OWL_OWLALL_H) && defined(__cplusplus)

#include "SftTbB.H"                     /* SftTabs OWL Support */

#endif

#endif  /* !RC_INVOKED */

#endif /* _INC_SFTTABS_2 */
