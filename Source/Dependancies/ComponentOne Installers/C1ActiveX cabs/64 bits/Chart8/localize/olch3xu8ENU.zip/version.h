/* defines precompiler variables used to build the version
   information throughout the resource files.
*/

#ifndef VFI_VERMAJ

#define VFI_VERMAJ	8
#define VFI_VERMIN	0
#define VFI_VERBLD	20173
#define VFI_VERBLD2	106

//#define QUARTER_RELEASE_DATESTR "05012006" 	/*NO UNICODE CONVERSION HERE*/
#define VFI_COPYRIGHT_STR "(c) GrapeCity, Inc. All rights reserved.\0" 	/*NO UNICODE CONVERSION HERE*/

#ifdef _DEBUG
 #ifdef _UNICODE
  #define VFI_VERSIONSTR	"8.0.20173.106UD"	/*NO UNICODE CONVERSION HERE*/
 #else
  #define VFI_VERSIONSTR	"8.0.20173.106D"	/*NO UNICODE CONVERSION HERE*/
 #endif
#else

 #ifdef _UNICODE
  #define VFI_VERSIONSTR	"8.0.20173.106U"	/*NO UNICODE CONVERSION HERE*/
 #else
  #define VFI_VERSIONSTR	"8.0.20173.106"		/*NO UNICODE CONVERSION HERE*/
 #endif

#endif

/* Translation definitions
*
*  UNICODE parameters are also required.
*  VFI parameter should match the compilation
*/
#define UNICODE_TRANSLATION_CODE	0x4B0
#define ANSI_TRANSLATION_CODE		0x4E4

#define USENGLISH_TRANSLATION_LANG	0x409
#define JAPANESE_TRANSLATION_LANG	0x411

/* Code */
#ifdef _UNICODE
  #define VFI_TRANSLATION_CODE UNICODE_TRANSLATION_CODE
#else
  #define VFI_TRANSLATION_CODE ANSI_TRANSLATION_CODE
#endif

/* Language */
#ifdef OLECTRA_JAPANESE
  #define VFI_TRANSLATION_LANG JAPANESE_TRANSLATION_LANG
#else
  #define VFI_TRANSLATION_LANG USENGLISH_TRANSLATION_LANG
#endif
#define UNICODE_TRANSLATION_LANG VFI_TRANSLATION_LANG

/* Translation Strings */
/*  these cannot be pasted together because of the RC compiler */
#ifdef OLECTRA_JAPANESE
  #define UNICODE_TRANSLATION_STR  "041104B0"	/*NO UNICODE CONVERSION HERE*/
#else
  #define UNICODE_TRANSLATION_STR  "040904B0"	/*NO UNICODE CONVERSION HERE*/
#endif

#ifdef _UNICODE
  #define VFI_TRANSLATION_STR  UNICODE_TRANSLATION_STR
#else
  #ifdef OLECTRA_JAPANESE
    #define VFI_TRANSLATION_STR  "041104E4"	/*NO UNICODE CONVERSION HERE*/
  #else
    #define VFI_TRANSLATION_STR  "040904E4"	/*NO UNICODE CONVERSION HERE*/
  #endif
#endif

/* WndClass Name definitions */

 #ifdef _UNICODE
  #ifdef XRT_STATICLIB
   #define XRT3DWNDCLASS "C1Chart3DSU8"		/*NO UNICODE CONVERSION HERE*/
  #else
   #define XRT3DWNDCLASS "C1Chart3DU8"		/*NO UNICODE CONVERSION HERE*/
  #endif
 #else
  #ifdef XRT_STATICLIB
   #define XRT3DWNDCLASS "C1Chart3DS8"		/*NO UNICODE CONVERSION HERE*/
  #else
   #define XRT3DWNDCLASS "C1Chart3D8"		/*NO UNICODE CONVERSION HERE*/
  #endif
 #endif

/* String IDs */

#define IDS_VFI_VERSION_ABOUT	5001
#define IDS_VFI_VERSIONSTR	5002

#endif
