/****************************************************************************/
/* SftTree 1.0 - Tree Custom Control for Windows                            */
/* Copyright (C) 1995  Softel vdm. All Rights Reserved.                     */
/****************************************************************************/

/* Tree Control */

#if !defined(_INC_SFTTREE)
#define _INC_SFTTREE                                /* only include once */

#if !defined(MSGF_MAINLOOP)
/* This #define was dropped from WINUSER in VC++ v6.0 */
#define MSGF_MAINLOOP       8
#endif

#define SFTTREE_CLASS16     "KLTreeControl"         /* Tree Control Window Class (16-bit) */
#define SFTTREE_CLASS32     "KLTreeControl"         /* Tree Control Window Class (32-bit) */
#define SFTTREE_CLASS       SFTTREE_CLASS32         /* Tree Control Window Class */

/* Tree Control Styles */

#define SFTTREESTYLE_DISABLENOSCROLL       0x0001L  /* Disable Scrollbars instead of hiding */
#define SFTTREESTYLE_WANTKEYBOARDINPUT     0x0002L  /* Parent wants WM_CHAR msgs */
#define SFTTREESTYLE_NOTIFY                0x0004L  /* Parent wants click,dblclk msgs */
#define SFTTREESTYLE_MULTIPLESEL           0x0008L  /* multiple selection */
#define SFTTREESTYLE_DRAGDROP              0x0010L  /* allow drag and drop */

#if !defined(RC_INVOKED)

#if defined(__cplusplus)
extern "C" {
 #define SFTSEND ::SendMessage
 #ifdef _WIN64
  #define SFTGWLNG ::GetWindowLongPtr
 #else
  #define SFTGWLNG ::GetWindowLong
 #endif
#else
 #define SFTSEND SendMessage
 #ifdef _WIN64
  #define SFTGWLNG GetWindowLongPtr
 #else
  #define SFTGWLNG GetWindowLong
 #endif
#endif

void WINAPI SftTree_RegisterApp(void);              /* Call to use SftTree with your application */
BOOL WINAPI SftTree_RegisterApp2(HINSTANCE hInst);  /* Call to use SftTree with your application */
void WINAPI SftTree_UnregisterApp2(HINSTANCE hInst);/* Call to end using SftTree with your application */

/* Tree Control Notification */

#define SFTTREEN_KILLFOCUS             2            /* Lost focus */
#define SFTTREEN_SETFOCUS              3            /* Got Focus */
#define SFTTREEN_SELCANCEL             4            /* cancel selection */
#define SFTTREEN_SELCHANGE             5            /* selection change */
#define SFTTREEN_CARETCHANGE           6            /* caret index change */
#define SFTTREEN_TOPCHANGE             7            /* top index change */
#define SFTTREEN_BEGINDRAG             8            /* begin dragging */
#define SFTTREEN_DRAGGING              9            /* dragging */
#define SFTTREEN_ENDDRAG               10           /* dropped */
#define SFTTREEN_CANCELDRAG            11           /* cancel dragging, aborted */
#define SFTTREEN_COLUMNSIZE            12           /* column size(s) changed */
/*                                     13              deliberately omitted */
#define SFTTREEN_QUITEDIT              14           /* end data editing (102) */
#define SFTTREEN_VALIDATEEDIT          15           /* validate data (102) */

/* left button  */
#define SFTTREEN_LBUTTONDOWN_LABEL     30           /* label clicked */
#define SFTTREEN_LBUTTONDOWN_PLUSMIN   31           /* +/- bitmap clicked */
#define SFTTREEN_LBUTTONDOWN_TREE      32           /* tree clicked */
#define SFTTREEN_LBUTTONDOWN_BUTTON    33           /* button clicked */
#define SFTTREEN_LBUTTONDOWN_ITEM      34           /* item bitmap clicked */
#define SFTTREEN_LBUTTONDOWN_TEXT      35           /* entry (text) clicked that's also a selection */
#define SFTTREEN_LBUTTONDOWN_COLUMN    36           /* column header clicked */
#define SFTTREEN_LBUTTONDBLCLK_LABEL   40           /* label double-clicked */
#define SFTTREEN_LBUTTONDBLCLK_PLUSMIN 41           /* +/- bitmap double-clicked */
#define SFTTREEN_LBUTTONDBLCLK_TREE    42           /* tree double-clicked */
#define SFTTREEN_LBUTTONDBLCLK_BUTTON  43           /* button double-clicked */
#define SFTTREEN_LBUTTONDBLCLK_ITEM    44           /* item bitmap double-clicked */
#define SFTTREEN_LBUTTONDBLCLK_TEXT    45           /* entry (text) double-clicked that's also a selection */
#define SFTTREEN_LBUTTONDBLCLK_COLUMN  46           /* column header double-clicked */
/* middle button */
#define SFTTREEN_MBUTTONDOWN_LABEL     50           /* label clicked */
#define SFTTREEN_MBUTTONDOWN_PLUSMIN   51           /* +/- bitmap clicked */
#define SFTTREEN_MBUTTONDOWN_TREE      52           /* tree clicked */
#define SFTTREEN_MBUTTONDOWN_BUTTON    53           /* button clicked */
#define SFTTREEN_MBUTTONDOWN_ITEM      54           /* item bitmap clicked */
#define SFTTREEN_MBUTTONDOWN_TEXT      55           /* entry (text) clicked that's also a selection */
#define SFTTREEN_MBUTTONDOWN_COLUMN    56           /* column header clicked */
#define SFTTREEN_MBUTTONDBLCLK_LABEL   60           /* label double-clicked */
#define SFTTREEN_MBUTTONDBLCLK_PLUSMIN 61           /* +/- bitmap double-clicked */
#define SFTTREEN_MBUTTONDBLCLK_TREE    62           /* tree double-clicked */
#define SFTTREEN_MBUTTONDBLCLK_BUTTON  63           /* button double-clicked */
#define SFTTREEN_MBUTTONDBLCLK_ITEM    64           /* item bitmap double-clicked */
#define SFTTREEN_MBUTTONDBLCLK_TEXT    65           /* entry (text) double-clicked, that's also a selection */
#define SFTTREEN_MBUTTONDBLCLK_COLUMN  66           /* column header double-clicked */
/* right button */
#define SFTTREEN_RBUTTONDOWN_LABEL     70           /* label clicked */
#define SFTTREEN_RBUTTONDOWN_PLUSMIN   71           /* +/- bitmap clicked */
#define SFTTREEN_RBUTTONDOWN_TREE      72           /* tree clicked */
#define SFTTREEN_RBUTTONDOWN_BUTTON    73           /* button clicked */
#define SFTTREEN_RBUTTONDOWN_ITEM      74           /* item bitmap clicked */
#define SFTTREEN_RBUTTONDOWN_TEXT      75           /* entry (text) clicked that's also a selection */
#define SFTTREEN_RBUTTONDOWN_COLUMN    76           /* column header clicked */
#define SFTTREEN_RBUTTONDBLCLK_LABEL   80           /* label double-clicked */
#define SFTTREEN_RBUTTONDBLCLK_PLUSMIN 81           /* +/- bitmap double-clicked */
#define SFTTREEN_RBUTTONDBLCLK_TREE    82           /* tree double-clicked */
#define SFTTREEN_RBUTTONDBLCLK_BUTTON  83           /* button double-clicked */
#define SFTTREEN_RBUTTONDBLCLK_ITEM    84           /* item bitmap double-clicked */
#define SFTTREEN_RBUTTONDBLCLK_TEXT    85           /* entry (text) double-clicked that's also a selection */
#define SFTTREEN_RBUTTONDBLCLK_COLUMN  86           /* column header double-clicked */

/* Misc. definitions for message parameter ids */

#define SFTTREE_MAXLEVELS 64                        /* levels 0 - 63 */

#define SFTTREE_SIBLING_FIRST           1           /* relationships */
#define SFTTREE_SIBLING_LAST            2
#define SFTTREE_SIBLING_PREV            3
#define SFTTREE_SIBLING_NEXT            4

#define SFTTREE_DEPENDENT_FIRST         1
#define SFTTREE_DEPENDENT_LAST          2

#define SFTTREE_OUTLINE_PLUS            0           /* Bitmap entries */
#define SFTTREE_OUTLINE_MINUS           1
#define SFTTREE_OUTLINE_NONE            2

/* Messages */

#define SFTTREEM_ADDSTRING_A    (WM_USER+5)          /* Add an ANSI string */
#define SFTTREEM_ADDSTRING_W    (WM_USER+6)          /* Add a UNICODE string */
#define SFTTREEM_INSERTSTRING_A (WM_USER+7)          /* Insert an ANSI string */
#define SFTTREEM_INSERTSTRING_W (WM_USER+8)          /* Insert a UNICODE string */
#define SFTTREEM_GETTEXT_A      (WM_USER+9)          /* Get item's text, ANSI */
#define SFTTREEM_GETTEXT_W      (WM_USER+10)         /* Get item's text, UNICODE */
#define SFTTREEM_SETTEXT_A      (WM_USER+11)         /* Set item's text, ANSI */
#define SFTTREEM_SETTEXT_W      (WM_USER+12)         /* Set item's text, UNICODE */
#define SFTTREEM_SETHEADER_A    (WM_USER+13)         /* Set header text ANSI */
#define SFTTREEM_SETHEADER_W    (WM_USER+14)         /* Set header text UNICODE */
#define SFTTREEM_GETHEADER_A    (WM_USER+15)         /* Get header text ANSI */
#define SFTTREEM_GETHEADER_W    (WM_USER+16)         /* Get header text UNICODE */

#define SFTTREEM_DELETESTRING   (WM_USER+20)         /* Delete an entry */
#define SFTTREEM_GETITEMLEVEL   (WM_USER+21)         /* Return item's level */
#define SFTTREEM_SETITEMLEVEL   (WM_USER+22)         /* Set item's level */
#define SFTTREEM_GETITEMSHOWN   (WM_USER+23)         /* Test if item shown */
#define SFTTREEM_SETITEMSHOWN   (WM_USER+24)         /* Show Item */
#define SFTTREEM_GETITEMLABEL   (WM_USER+25)         /* Return item's label bitmap */
#define SFTTREEM_SETITEMLABEL   (WM_USER+26)         /* Set item's label bitmap */
#define SFTTREEM_GETITEMBITMAP  (WM_USER+27)         /* Return item's bitmap */
#define SFTTREEM_SETITEMBITMAP  (WM_USER+28)         /* Set item's bitmap */
#define SFTTREEM_GETITEMEXPAND  (WM_USER+29)         /* Return item's expansion status */
#define SFTTREEM_SETITEMEXPAND  (WM_USER+30)         /* Set item's expansion status */
#define SFTTREEM_GETITEMSTATUS  (WM_USER+31)         /* Return item's expansion status */
#define SFTTREEM_SETITEMSTATUS  (WM_USER+32)         /* Set item's expansion status */
#define SFTTREEM_GETCARETINDEX  (WM_USER+33)         /* Return item with focus rectangle */
#define SFTTREEM_SETCARETINDEX  (WM_USER+34)         /* Set item with focus rectangle */
#define SFTTREEM_GETCOUNT       (WM_USER+35)         /* Return # of items in tree */
#define SFTTREEM_GETCURSEL      (WM_USER+36)         /* Get selection (single) */
#define SFTTREEM_SETCURSEL      (WM_USER+37)         /* Select item (single) */
#define SFTTREEM_GETITEMDATA    (WM_USER+38)         /* Get item's data component */
#define SFTTREEM_SETITEMDATA    (WM_USER+39)         /* Set item's data component */
#define SFTTREEM_GETITEMHEIGHT  (WM_USER+40)         /* Get item height */
#define SFTTREEM_GETITEMRECT    (WM_USER+41)         /* Get item's rectangle */
#define SFTTREEM_GETSEL         (WM_USER+42)         /* Get item's selection state */
#define SFTTREEM_SETSEL         (WM_USER+43)         /* Set item's selection status */
#define SFTTREEM_GETSELCOUNT    (WM_USER+44)         /* Get selection count */
#define SFTTREEM_GETSELITEMS    (WM_USER+45)         /* Get selected items (multiple) */
#define SFTTREEM_GETTEXTLENGTH  (WM_USER+46)         /* Get item's text length */
#define SFTTREEM_GETHEADERLENGTH \
                                (WM_USER+47)         /* Get header text length */
#define SFTTREEM_GETTOPINDEX    (WM_USER+48)         /* Get item on top of display */
#define SFTTREEM_SETTOPINDEX    (WM_USER+49)         /* Set first item in display area */
#define SFTTREEM_RESETCONTENT   (WM_USER+50)         /* Clear contents */
#define SFTTREEM_SELITEMRANGE   (WM_USER+51)         /* Select range of items (multiple) */
#define SFTTREEM_GETPARENT      (WM_USER+52)         /* Get item's parent */
#define SFTTREEM_GETTOPPARENT   (WM_USER+53)         /* Get item's top level parent */
#define SFTTREEM_GETSIBLING     (WM_USER+54)         /* Get item's sibling (first,last,prev,next) */
#define SFTTREEM_GETDEPENDENTCOUNT \
                                (WM_USER+55)         /* Get # of dependents */
#define SFTTREEM_GETDEPENDENT   (WM_USER+56)         /* Get an item's dependent */
#define SFTTREEM_CALCINDEXFROMPOINT \
                                (WM_USER+57)         /* Calc index from client coordinate */
#define SFTTREEM_GETSHOWLABELS  (WM_USER+58)         /* Get Label Bitmap Status */
#define SFTTREEM_GETSHOWPLUSMINUS \
                                (WM_USER+59)         /* Get +/- Status */
#define SFTTREEM_SETPLUSMINUS   (WM_USER+60)         /* Set +/- bitmaps */
#define SFTTREEM_GETSHOWTREELINES \
                                (WM_USER+61)         /* Get Tree Lines Status */
#define SFTTREEM_SETSHOWTREELINES \
                                (WM_USER+62)         /* Show/Hide Tree Lines/Buttons */
#define SFTTREEM_SETBITMAPS     (WM_USER+63)         /* Set Default Item Bitmaps */
#define SFTTREEM_GETSHOWBITMAPS (WM_USER+64)         /* Get Item Bitmap Status */
#define SFTTREEM_SETSELTEXTONLY (WM_USER+65)         /* Get Select text only Status */
#define SFTTREEM_GETSELTEXTONLY (WM_USER+66)         /* Set Select text only Status */
#define SFTTREEM_GETDRAGINFO    (WM_USER+67)         /* Get Drag Information */
#define SFTTREEM_SETDISABLENOSCROLL \
                                (WM_USER+68)         /* Scroll bar disabling */
#define SFTTREEM_GETCOLUMNS     (WM_USER+69)         /* Get Columns */
#define SFTTREEM_SETCOLUMNS     (WM_USER+70)         /* Set Columns */
#define SFTTREEM_SETBUTTONS     (WM_USER+71)         /* Set Tree Buttons */
#define SFTTREEM_GETSHOWBUTTONS (WM_USER+72)         /* Get Button Status */
#define SFTTREEM_SETSHOWBUTTONS (WM_USER+73)         /* Show/Hide Tree Buttons */
#define SFTTREEM_GETSHOWBUTTON0 (WM_USER+74)         /* Get Button Status level 0 */
#define SFTTREEM_SETSHOWBUTTON0 (WM_USER+75)         /* Show/Hide Tree Buttons level 0 */
#define SFTTREEM_GETHORIZONTALEXTENT \
                                (WM_USER+80)         /* Get Horizontal Scrolling extent */
#define SFTTREEM_SETHORIZONTALEXTENT \
                                (WM_USER+81)         /* Set Horizontal Scrolling extent */
#define SFTTREEM_RECALCHORIZONTALEXTENT \
                                (WM_USER+82)         /* Calculate Horizontal Scrolling extent */
#define SFTTREEM_GETHORIZONTALOFFSET \
                                (WM_USER+83)         /* Get Horizontal Scrolling offset */
#define SFTTREEM_SETHORIZONTALOFFSET \
                                (WM_USER+84)         /* Set Horizontal Scrolling offset */
#define SFTTREEM_SETITEMLINES   (WM_USER+85)         /* Set # of text lines per item */
#define SFTTREEM_GETITEMLINES   (WM_USER+86)         /* Get # of text lines per item */
#define SFTTREEM_GETACCESSCOLUMN \
                                (WM_USER+87)         /* Get column accessed by Get/SetText */
#define SFTTREEM_SETACCESSCOLUMN \
                                (WM_USER+88)         /* Get column accessed by Get/SetText */
#define SFTTREEM_SETHEADERFONT  (WM_USER+89)         /* Set font for header */
#define SFTTREEM_GETHEADERFONT  (WM_USER+90)         /* Get font for header */
#define SFTTREEM_SETSHOWHEADER  (WM_USER+91)         /* Set header status */
#define SFTTREEM_GETSHOWHEADER  (WM_USER+92)         /* Get header status */
#define SFTTREEM_SETSHOW3D      (WM_USER+93)         /* Set 3D Mode */
#define SFTTREEM_GETSHOW3D      (WM_USER+94)         /* Get 3D Mode */
#define SFTTREEM_SETSHOWGRID    (WM_USER+95)         /* Set Grid Display */
#define SFTTREEM_GETSHOWGRID    (WM_USER+96)         /* Get Grid Display */
#define SFTTREEM_SORTDEPENDENTS (WM_USER+97)         /* Sort dependents */
#define SFTTREEM_SETDRAWINFOCALLBACK \
                                (WM_USER+98)         /* Register drawing info callback */
#define SFTTREEM_SETSHOWHEADERBUTTONS \
                                (WM_USER+99)         /* Set header button status */
#define SFTTREEM_GETSHOWHEADERBUTTONS \
                                (WM_USER+100)        /* Get header button status */
#define SFTTREEM_SETHEADERBUTTON \
                                (WM_USER+101)        /* Set active header button */
#define SFTTREEM_GETHEADERBUTTON \
                                (WM_USER+102)        /* Get active header button */
#define SFTTREEM_SETRESIZEHEADER \
                                (WM_USER+103)        /* Set resizable headers */
#define SFTTREEM_GETRESIZEHEADER \
                                (WM_USER+104)        /* Get resizable header status */
#define SFTTREEM_GETEDITCOLUMNRECT  \
                                (WM_USER+105)        /* Get edit column rectangle */
#define SFTTREEM_ENSUREVISIBLE  \
                                (WM_USER+106)        /* Scroll item into view */

#if defined(_MSC_VER)
# pragma pack(1)                        /* Packing */
#endif
#if defined(__BORLANDC__)
# pragma option -a1
#endif

/* Drag information, valid after SFTTREEN_BEGINDRAG, SFTTREEN_DRAGGING, SFTTREEN_ENDDRAG */
/* retrieve using SFTTREEM_GETDRAGINFO message */

typedef struct tagDragInfo {

    /* read/only fields */
    POINT ptDrag;                       /* screen coordinate of mouse */
    HWND hwnd;                          /* window under mouse cursor */
    int index;                          /* current drop entry, -1 if dropped */
                                        /* outside of tree */
    BOOL fMultiple;                     /* moving/copying more than one item */
    BOOL fControl;                      /* TRUE if control key pressed */
    BOOL fShift;                        /* TRUE if shift key pressed */
    int button;                         /* button used for dragging */
#define SFTTREE_LBUTTON    1
#define SFTTREE_MBUTTON    2
#define SFTTREE_RBUTTON    3

    /* fields set by application: */
    BOOL fDropOK;                       /* set to FALSE if drop not possible */
    HCURSOR hCursor;                    /* application sets cursor (drag) */

} SFTTREE_DRAGINFO, FAR * LPSFTTREE_DRAGINFO;

/* Column info - for use with SFTTREEM_GETCOLUMNS/SFTTREEM_SETCOLUMNS */

typedef struct tagColumn {              
    int width;                          /* column width */
    DWORD style;                        /* column cell alignment */
                                        /* use ES_LEFT, ES_CENTER, ES_RIGHT edit window styles */
                                        /* ES_MULTILINE if more than one text line */
    DWORD styleTitle;                   /* column title style */
#if defined(UNICODE) || defined(_UNICODE)
     LPTSTR lpszTitle;                  /* column title */
#else
     LPSTR lpszTitle;                   /* column title */
#endif
     /* do not get/set lpszTitle directly, use SFTTREEM_GETHEADER/SFTTREEM_SETHEADER instead */
} SFTTREE_COLUMN, FAR * LPSFTTREE_COLUMN;

/* Sort Callback - User supplied */
#if defined(UNICODE) || defined(_UNICODE)
typedef int (CALLBACK* SFTTREE_SORTPROC)(HWND hwnd, LPCWSTR lpszString1, LPCWSTR lpszString2);
#else
typedef int (CALLBACK* SFTTREE_SORTPROC)(HWND hwnd, LPCSTR lpszString1, LPCSTR lpszString2);
#endif

/* Drawing information */

typedef struct tagDrawingInfo {

    /* read/only fields  */
    UINT id;                            /* Control's ID */
    HWND hwndCtl;                       /* Control's window handle */
    int index;                          /* entry being draw */
    BOOL fSelected;                     /* non-zero if item selected */
    BOOL fExpandable, fExpanded;        /* item status */
    int nCols;                          /* # of columns */
                                                      
    /* fields settable by application: */
    COLORREF colorFg, colorBg;          /* foreground/background colors (other than text area) */
    COLORREF colorFgText, colorBgText;  /* foreground/background colors (text area) */
    HFONT hFont;                        /* Font for Text */
    HBITMAP hLabelBitmap;               /* label bitmap */
    HBITMAP hPlusMinBitmap;             /* +/- bitmap */
    HBITMAP hItemBitmap;                /* item bitmap */
    HPEN hTreePen;                      /* Pen for tree lines, if NULL a pen of colorFg is created */
    BOOL fEnabled;                      /* non-zero if tree/item enabled */

#if defined(UNICODE) || defined(_UNICODE)
     LPWSTR FAR* lplpszString;           /* ptr to ptrs to strings for each column */
#else
     LPSTR FAR* lplpszString;            /* ptr to ptrs to strings for each column */
#endif
     /* user may replace this pointer, however, modifications to the strings directly are not allowed */
} SFTTREE_DRAWINGINFO, FAR * LPSFTTREE_DRAWINGINFO;

typedef void (CALLBACK* SFTTREE_DRAWINFOPROC)(HWND hwnd, LPSFTTREE_DRAWINGINFO lpInfo, DWORD UserData);

typedef struct tagDrawInfoParm {
    SFTTREE_DRAWINFOPROC lpfnDrawInfo;  /* User supplied drawing info routine */
    DWORD UserData;                     /* User supplied data */
} SFTTREE_DRAWINFOPARM, FAR * LPSFTTREE_DRAWINFOPARM;

#if defined(_MSC_VER)
# pragma pack()                         /* Packing */
#endif
#if defined(__BORLANDC__)
# pragma option -a-
#endif

/* Message Crackers */

#if defined(UNICODE) || defined(_UNICODE)

/* int Cls_OnAddString_W(HWND hwnd, LPCWSTR lpszText); */
#define SFTTREEM_ADDSTRING      SFTTREEM_ADDSTRING_W
#define HANDLE_SFTTREEM_ADDSTRING_W(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPCWSTR)(lParam))
#define FORWARD_SFTTREEM_ADDSTRING_W(hwnd, lpszText, fn) \
    (int)(fn)((hwnd), SFTTREEM_ADDSTRING_W, 0, (LPARAM)(LPCWSTR)(lpszText))
#define SftTree_AddString      SftTree_AddString_W
#define SftTree_AddString_W(hwnd, lpszText) \
                                FORWARD_SFTTREEM_ADDSTRING_W((hwnd), (lpszText), SFTSEND)

/* int Cls_OnInsertString_W(HWND hwnd, int index, LPCWSTR lpszText); */
#define SFTTREEM_INSERTSTRING   SFTTREEM_INSERTSTRING_W
#define HANDLE_SFTTREEM_INSERTSTRING_W(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (LPCWSTR)(lParam))
#define FORWARD_SFTTREEM_INSERTSTRING_W(hwnd, index, lpszText, fn) \
    (int)(fn)((hwnd), SFTTREEM_INSERTSTRING_W, (WPARAM)(index), (LPARAM)(LPCWSTR)(lpszText))
#define SftTree_InsertString   SftTree_InsertString_W
#define SftTree_InsertString_W(hwnd, index, lpszText) \
                                FORWARD_SFTTREEM_INSERTSTRING_W((hwnd), (index), (lpszText), SFTSEND)

/* int Cls_OnGetText_W(HWND hwnd, int index, LPWSTR lpszBuffer); */
#define SFTTREEM_GETTEXT        SFTTREEM_GETTEXT_W
#define HANDLE_SFTTREEM_GETTEXT_W(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (LPWSTR)(lParam))
#define FORWARD_SFTTREEM_GETTEXT_W(hwnd, index, lpszBuffer, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETTEXT_W, (WPARAM)(index), (LPARAM)(LPWSTR)(lpszBuffer))
#define SftTree_GetText        SftTree_GetText_W
#define SftTree_GetText_W(hwnd, index, lpszText) \
                                FORWARD_SFTTREEM_GETTEXT_W((hwnd), (index), (lpszText), SFTSEND)

/* BOOL Cls_OnSetText_W(HWND hwnd, int index, LPCWSTR lpszBuffer); */
#define SFTTREEM_SETTEXT        SFTTREEM_SETTEXT_W
#define HANDLE_SFTTREEM_SETTEXT_W(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (LPCWSTR)(lParam))
#define FORWARD_SFTTREEM_SETTEXT_W(hwnd, index, lpszBuffer, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETTEXT_W, (WPARAM)(index), (LPARAM)(LPCWSTR)(lpszBuffer))
#define SftTree_SetText        SftTree_SetText_W
#define SftTree_SetText_W(hwnd, index, lpszText) \
                                FORWARD_SFTTREEM_SETTEXT_W((hwnd), (index), (lpszText), SFTSEND)

/* int Cls_OnGetHeader_W(HWND hwnd, LPWSTR lpszBuffer, int cbMax); */
#define SFTTREEM_GETHEADER      SFTTREEM_GETHEADER_W
#define HANDLE_SFTTREEM_GETHEADER_W(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPWSTR)(lParam), (int) (wParam))
#define FORWARD_SFTTREEM_GETHEADER_W(hwnd, lpszBuffer, cbMax, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETHEADER_W, (WPARAM)(cbMax), (LPARAM)(LPWSTR)(lpszBuffer))
#define SftTree_GetHeader      SftTree_GetHeader_W
#define SftTree_GetHeader_W(hwnd, index, lpszText) \
                                FORWARD_SFTTREEM_GETHEADER_W((hwnd), (lpszText), (cbMax), SFTSEND)

/* BOOL Cls_OnSetHeader_W(HWND hwnd, LPCWSTR lpszBuffer); */
#define SFTTREEM_SETHEADER      SFTTREEM_SETHEADER_W
#define HANDLE_SFTTREEM_SETHEADER_W(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPCWSTR)(lParam))
#define FORWARD_SFTTREEM_SETHEADER_W(hwnd, lpszBuffer, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETHEADER_W, 0, (LPARAM)(LPCWSTR)(lpszBuffer))
#define SftTree_SetHeader      SftTree_SetHeader_W
#define SftTree_SetHeader_W(hwnd, lpszText) \
                                FORWARD_SFTTREEM_SETHEADER_W((hwnd), (lpszText), SFTSEND)

#else

#define SFTTREEM_ADDSTRING      SFTTREEM_ADDSTRING_A
#define SftTree_AddString      SftTree_AddString_A
#define SFTTREEM_INSERTSTRING   SFTTREEM_INSERTSTRING_A
#define SftTree_InsertString   SftTree_InsertString_A
#define SFTTREEM_GETTEXT        SFTTREEM_GETTEXT_A
#define SftTree_GetText        SftTree_GetText_A
#define SFTTREEM_SETTEXT        SFTTREEM_SETTEXT_A
#define SftTree_SetText        SftTree_SetText_A
#define SFTTREEM_GETHEADER      SFTTREEM_GETHEADER_A
#define SftTree_GetHeader      SftTree_GetHeader_A
#define SFTTREEM_SETHEADER        SFTTREEM_SETHEADER_A
#define SftTree_SetHeader      SftTree_SetHeader_A

#endif /* UNICODE */

/* int Cls_OnAddString_A(HWND hwnd, LPCSTR lpszText); */
#define HANDLE_SFTTREEM_ADDSTRING_A(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPCSTR)(lParam))
#define FORWARD_SFTTREEM_ADDSTRING_A(hwnd, lpszText, fn) \
    (int)(fn)((hwnd), SFTTREEM_ADDSTRING_A, 0, (LPARAM)(LPCSTR)(lpszText))
#define SftTree_AddString_A(hwnd, lpszText) \
                                FORWARD_SFTTREEM_ADDSTRING_A((hwnd), (lpszText), SFTSEND)

/* int Cls_OnInsertString_A(HWND hwnd, int index, LPCSTR lpszText); */
#define HANDLE_SFTTREEM_INSERTSTRING_A(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (LPCSTR)(lParam))
#define FORWARD_SFTTREEM_INSERTSTRING_A(hwnd, index, lpszText, fn) \
    (int)(fn)((hwnd), SFTTREEM_INSERTSTRING_A, (WPARAM)(index), (LPARAM)(LPCSTR)(lpszText))
#define SftTree_InsertString_A(hwnd, index, lpszText) \
                                FORWARD_SFTTREEM_INSERTSTRING_A((hwnd), (index), (lpszText), SFTSEND)

/* int Cls_OnGetText_A(HWND hwnd, int index, LPSTR lpszBuffer); */
#define HANDLE_SFTTREEM_GETTEXT_A(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (LPSTR)(lParam))
#define FORWARD_SFTTREEM_GETTEXT_A(hwnd, index, lpszBuffer, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETTEXT_A, (WPARAM)(index), (LPARAM)(LPSTR)(lpszBuffer))
#define SftTree_GetText_A(hwnd, index, lpszText) \
                                FORWARD_SFTTREEM_GETTEXT_A((hwnd), (index), (lpszText), SFTSEND)

/* BOOL Cls_OnSetText_A(HWND hwnd, int index, LPCSTR lpszBuffer); */
#define HANDLE_SFTTREEM_SETTEXT_A(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (LPCSTR)(lParam))
#define FORWARD_SFTTREEM_SETTEXT_A(hwnd, index, lpszBuffer, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETTEXT_A, (WPARAM)(index), (LPARAM)(LPCSTR)(lpszBuffer))
#define SftTree_SetText_A(hwnd, index, lpszText) \
                                FORWARD_SFTTREEM_SETTEXT_A((hwnd), (index), (lpszText), SFTSEND)

/* int Cls_OnGetHeader_A(HWND hwnd, LPSTR lpszBuffer, int cbMax); */
#define HANDLE_SFTTREEM_GETHEADER_A(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPSTR)(lParam), (int)(wParam))
#define FORWARD_SFTTREEM_GETHEADER_A(hwnd, lpszBuffer, cbMax, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETHEADER_A, (WPARAM)(cbMax), (LPARAM)(LPSTR)(lpszBuffer))
#define SftTree_GetHeader_A(hwnd, lpszText, cbMax) \
                                FORWARD_SFTTREEM_GETHEADER_A((hwnd), (lpszText), (cbMax), SFTSEND)

/* BOOL Cls_OnSetHeader_A(HWND hwnd, LPCSTR lpszBuffer); */
#define HANDLE_SFTTREEM_SETHEADER_A(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPCSTR)(lParam))
#define FORWARD_SFTTREEM_SETHEADER_A(hwnd, lpszBuffer, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETHEADER_A, 0, (LPARAM)(LPCSTR)(lpszBuffer))
#define SftTree_SetHeader_A(hwnd, lpszText) \
                                FORWARD_SFTTREEM_SETHEADER_A((hwnd), (lpszText), SFTSEND)

/* int Cls_OnDeleteString(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_DELETESTRING(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam))
#define FORWARD_SFTTREEM_DELETESTRING(hwnd, index, fn) \
    (int)(fn)((hwnd), SFTTREEM_DELETESTRING, (WPARAM)(index), 0)
#define SftTree_DeleteString(hwnd, index) \
                                FORWARD_SFTTREEM_DELETESTRING((hwnd), (index), SFTSEND)

/* int Cls_OnGetItemLevel(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_GETITEMLEVEL(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam))
#define FORWARD_SFTTREEM_GETITEMLEVEL(hwnd, index, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETITEMLEVEL, (WPARAM)(index), 0)
#define SftTree_GetItemLevel(hwnd, index) \
                                FORWARD_SFTTREEM_GETITEMLEVEL((hwnd), (index), SFTSEND)

/* BOOL Cls_OnSetItemLevel(HWND hwnd, int index, int level); */
#define HANDLE_SFTTREEM_SETITEMLEVEL(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (int)(lParam))
#define FORWARD_SFTTREEM_SETITEMLEVEL(hwnd, index, level, fn) \
    (int)(fn)((hwnd), SFTTREEM_SETITEMLEVEL, (WPARAM)(index), (LPARAM)(level))
#define SftTree_SetItemLevel(hwnd, index, level) \
                                FORWARD_SFTTREEM_SETITEMLEVEL((hwnd), (index), (level), SFTSEND)

/* BOOL Cls_OnGetItemShown(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_GETITEMSHOWN(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)wParam)
#define FORWARD_SFTTREEM_GETITEMSHOWN(hwnd, index, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETITEMSHOWN, (WPARAM)(index), 0)
#define SftTree_GetItemShown(hwnd, index) \
                                FORWARD_SFTTREEM_GETITEMSHOWN((hwnd), (index), SFTSEND)

/* BOOL Cls_OnSetItemShown(HWND hwnd, int index, BOOL fShown); */
#define HANDLE_SFTTREEM_SETITEMSHOWN(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (BOOL)(lParam))
#define FORWARD_SFTTREEM_SETITEMSHOWN(hwnd, index, fShown, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETITEMSHOWN, (WPARAM)(index), (LPARAM)(fShown))
#define SftTree_SetItemShown(hwnd, index, fShown) \
                                FORWARD_SFTTREEM_SETITEMSHOWN((hwnd), (index), (fShown), SFTSEND)

/* HBITMAP Cls_OnGetItemLabel(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_GETITEMLABEL(hwnd, wParam, lParam, fn) \
    (LRESULT)(UINT)(fn)((hwnd), (int)(wParam))
#define FORWARD_SFTTREEM_GETITEMLABEL(hwnd, index, fn) \
    (HBITMAP)(UINT)(fn)((hwnd), SFTTREEM_GETITEMLABEL, (WPARAM)(index), 0)
#define SftTree_GetItemLabel(hwnd, index) \
                                FORWARD_SFTTREEM_GETITEMLABEL((hwnd), (index), SFTSEND)

/* BOOL Cls_OnSetItemLabel(HWND hwnd, int index, HBITMAP hBitmap); */
#define HANDLE_SFTTREEM_SETITEMLABEL(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (HBITMAP)(UINT)(lParam))
#define FORWARD_SFTTREEM_SETITEMLABEL(hwnd, index, hBitmap, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETITEMLABEL, (WPARAM)(index), (LPARAM)(UINT)(HBITMAP)(hBitmap))
#define SftTree_SetItemLabel(hwnd, index, hBitmap) \
                                FORWARD_SFTTREEM_SETITEMLABEL((hwnd), (index), (hBitmap), SFTSEND)

/* HBITMAP Cls_OnGetItemBitmap(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_GETITEMBITMAP(hwnd, wParam, lParam, fn) \
    (LRESULT)(UINT)(fn)((hwnd), (int)(wParam))
#define FORWARD_SFTTREEM_GETITEMBITMAP(hwnd, index, fn) \
    (HBITMAP)(UINT)(fn)((hwnd), SFTTREEM_GETITEMBITMAP, (WPARAM)(index), 0)
#define SftTree_GetItemBitmap(hwnd, index) \
                                FORWARD_SFTTREEM_GETITEMBITMAP((hwnd), (index), SFTSEND)

/* BOOL Cls_OnSetItemBitmap(HWND hwnd, int index, HBITMAP hBitmap); */
#define HANDLE_SFTTREEM_SETITEMBITMAP(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (HBITMAP)(UINT)(lParam))
#define FORWARD_SFTTREEM_SETITEMBITMAP(hwnd, index, hBitmap, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETITEMBITMAP, (WPARAM)(index), (LPARAM)(UINT)(HBITMAP)(hBitmap))
#define SftTree_SetItemBitmap(hwnd, index, hBitmap) \
                                FORWARD_SFTTREEM_SETITEMBITMAP((hwnd), (index), (hBitmap), SFTSEND)

/* BOOL Cls_OnGetItemExpand(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_GETITEMEXPAND(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)wParam)
#define FORWARD_SFTTREEM_GETITEMEXPAND(hwnd, index, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETITEMEXPAND, (WPARAM)(index), 0)
#define SftTree_GetItemExpand(hwnd, index) \
                                FORWARD_SFTTREEM_GETITEMEXPAND((hwnd), (index), SFTSEND)

/* BOOL Cls_OnSetItemExpand(HWND hwnd, int index, BOOL fExpand, BOOL fDepth); */
#define HANDLE_SFTTREEM_SETITEMEXPAND(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (BOOL)LOWORD((lParam)), (BOOL)HIWORD((lParam)))
#define FORWARD_SFTTREEM_SETITEMEXPAND(hwnd, index, fExpand, fDepth, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETITEMEXPAND, (WPARAM)(index), (LPARAM)MAKELPARAM((WORD)(fExpand), (WORD)(fDepth)))
#define SftTree_SetItemExpand(hwnd, index, fExpand, fDepth) \
                                FORWARD_SFTTREEM_SETITEMEXPAND((hwnd), (index), (fExpand), (fDepth), SFTSEND)

/* BOOL Cls_OnGetItemStatus(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_GETITEMSTATUS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)wParam)
#define FORWARD_SFTTREEM_GETITEMSTATUS(hwnd, index, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETITEMSTATUS, (WPARAM)(index), 0)
#define SftTree_GetItemStatus(hwnd, index) \
                                FORWARD_SFTTREEM_GETITEMSTATUS((hwnd), (index), SFTSEND)

/* BOOL Cls_OnSetItemStatus(HWND hwnd, int index, BOOL fEnable); */
#define HANDLE_SFTTREEM_SETITEMSTATUS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (BOOL)(lParam))
#define FORWARD_SFTTREEM_SETITEMSTATUS(hwnd, index, fEnable, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETITEMSTATUS, (WPARAM)(index), (LPARAM)(fEnable))
#define SftTree_SetItemStatus(hwnd, index, fEnable) \
                                FORWARD_SFTTREEM_SETITEMSTATUS((hwnd), (index), (fEnable), SFTSEND)

/* int Cls_OnGetCaretIndex(HWND hwnd); */
#define HANDLE_SFTTREEM_GETCARETINDEX(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETCARETINDEX(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETCARETINDEX, 0, 0)
#define SftTree_GetCaretIndex(hwnd) \
                                FORWARD_SFTTREEM_GETCARETINDEX((hwnd), SFTSEND)

/* int Cls_OnSetCaretIndex(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_SETCARETINDEX(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam))
#define FORWARD_SFTTREEM_SETCARETINDEX(hwnd, index, fn) \
    (int)(fn)((hwnd), SFTTREEM_SETCARETINDEX, (WPARAM)(index), 0)
#define SftTree_SetCaretIndex(hwnd, index) \
                                FORWARD_SFTTREEM_SETCARETINDEX((hwnd), (index), SFTSEND)

/* int Cls_OnGetCount(HWND hwnd); */
#define HANDLE_SFTTREEM_GETCOUNT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETCOUNT(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETCOUNT, 0, 0)
#define SftTree_GetCount(hwnd) \
                                FORWARD_SFTTREEM_GETCOUNT((hwnd), SFTSEND)

/* int Cls_OnGetCurSel(HWND hwnd); */
#define HANDLE_SFTTREEM_GETCURSEL(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETCURSEL(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETCURSEL, 0, 0)
#define SftTree_GetCurSel(hwnd) \
                                FORWARD_SFTTREEM_GETCURSEL((hwnd), SFTSEND)

/* int Cls_OnSetCurSel(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_SETCURSEL(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam))
#define FORWARD_SFTTREEM_SETCURSEL(hwnd, index, fn) \
    (int)(fn)((hwnd), SFTTREEM_SETCURSEL, (WPARAM)(index), (LPARAM)0)
#define SftTree_SetCurSel(hwnd, index) \
                                FORWARD_SFTTREEM_SETCURSEL((hwnd), (index), SFTSEND)

/* DWORD Cls_OnGetItemData(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_GETITEMDATA(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam))
#ifdef _WIN64
  #define FORWARD_SFTTREEM_GETITEMDATA(hwnd, index, fn) \
    (LRESULT)(fn)((hwnd), SFTTREEM_GETITEMDATA, (WPARAM)(index), 0)
#else
  #define FORWARD_SFTTREEM_GETITEMDATA(hwnd, index, fn) \
    (DWORD)(fn)((hwnd), SFTTREEM_GETITEMDATA, (WPARAM)(index), 0)
#endif
#define SftTree_GetItemData(hwnd, index) \
                                FORWARD_SFTTREEM_GETITEMDATA((hwnd), (index), SFTSEND)

/* int Cls_OnSetItemData(HWND hwnd, int index, DWORD dwd); */
#ifdef _WIN64
  #define HANDLE_SFTTREEM_SETITEMDATA(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (LPARAM)(lParam))
#else
  #define HANDLE_SFTTREEM_SETITEMDATA(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (DWORD)(lParam))
#endif
#ifdef _WIN64
  #define FORWARD_SFTTREEM_SETITEMDATA(hwnd, index, dwd, fn) \
    (int)(fn)((hwnd), SFTTREEM_SETITEMDATA, (WPARAM)(index), (LPARAM)(dwd))
#else
  #define FORWARD_SFTTREEM_SETITEMDATA(hwnd, index, dwd, fn) \
    (int)(fn)((hwnd), SFTTREEM_SETITEMDATA, (WPARAM)(index), (LPARAM)(DWORD)(dwd))
#endif
#define SftTree_SetItemData(hwnd, index, dwdData) \
                                FORWARD_SFTTREEM_SETITEMDATA((hwnd), (index), (dwdData), SFTSEND)

/* int Cls_OnGetItemHeight(HWND hwnd); */
#define HANDLE_SFTTREEM_GETITEMHEIGHT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETITEMHEIGHT(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETITEMHEIGHT, 0, 0)
#define SftTree_GetItemHeight(hwnd) \
                                FORWARD_SFTTREEM_GETITEMHEIGHT((hwnd), SFTSEND)

/* int Cls_OnGetItemRect(HWND hwnd, int index, LPRECT lpRect); */
#define HANDLE_SFTTREEM_GETITEMRECT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (LPRECT)(lParam))
#define FORWARD_SFTTREEM_GETITEMRECT(hwnd, index, lpRect, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETITEMRECT, (WPARAM)(index), (LPARAM)(LPRECT)(lpRect))
#define SftTree_GetItemRect(hwnd, index, lpRect) \
                                FORWARD_SFTTREEM_GETITEMRECT((hwnd), (index), (lpRect), SFTSEND)

/* int Cls_OnGetSel(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_GETSEL(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam))
#define FORWARD_SFTTREEM_GETSEL(hwnd, index, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETSEL, (WPARAM)(index), 0)
#define SftTree_GetSel(hwnd, index) \
                                FORWARD_SFTTREEM_GETSEL((hwnd), (index), SFTSEND)

/* int Cls_OnSetSel(HWND hwnd, int index, BOOL fSelect); */
#define HANDLE_SFTTREEM_SETSEL(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (lParam), (BOOL)(wParam))
#define FORWARD_SFTTREEM_SETSEL(hwnd, index, fSelect, fn) \
    (int)(fn)((hwnd), SFTTREEM_SETSEL, (WPARAM)(fSelect), (LPARAM)(index))
#define SftTree_SetSel(hwnd, index, fStatus) \
                                FORWARD_SFTTREEM_SETSEL((hwnd), (index), (fStatus), SFTSEND)

/* int Cls_OnGetSelCount(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSELCOUNT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSELCOUNT(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETSELCOUNT, 0, 0)
#define SftTree_GetSelCount(hwnd) \
                                FORWARD_SFTTREEM_GETSELCOUNT((hwnd), SFTSEND)

/* int Cls_OnGetSelItems(HWND hwnd, int max, LPINT lpItems); */
#define HANDLE_SFTTREEM_GETSELITEMS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (LPINT)(lParam))
#define FORWARD_SFTTREEM_GETSELITEMS(hwnd, max, lpItems, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETSELITEMS, (WPARAM)(max), (LPARAM)(LPINT)(lpItems))
#define SftTree_GetSelItems(hwnd, max, lpItems) \
                                FORWARD_SFTTREEM_GETSELITEMS((hwnd), (max), (lpItems), SFTSEND)

/* int Cls_OnGetTextLength(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_GETTEXTLENGTH(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam))
#define FORWARD_SFTTREEM_GETTEXTLENGTH(hwnd, index, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETTEXTLENGTH, (WPARAM)(index), (LPARAM)0)
#define SftTree_GetTextLength(hwnd, index) \
                                FORWARD_SFTTREEM_GETTEXTLENGTH((hwnd), (index), SFTSEND)

/* int Cls_OnGetHeaderLength(HWND hwnd); */
#define HANDLE_SFTTREEM_GETHEADERLENGTH(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETHEADERLENGTH(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETHEADERLENGTH, (WPARAM)0, (LPARAM)0)
#define SftTree_GetHeaderLength(hwnd) \
                                FORWARD_SFTTREEM_GETHEADERLENGTH((hwnd), SFTSEND)

/* int Cls_OnGetTopIndex(HWND hwnd); */
#define HANDLE_SFTTREEM_GETTOPINDEX(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETTOPINDEX(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETTOPINDEX, 0, 0)
#define SftTree_GetTopIndex(hwnd) \
                                FORWARD_SFTTREEM_GETTOPINDEX((hwnd), SFTSEND)

/* int Cls_OnSetTopIndex(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_SETTOPINDEX(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam))
#define FORWARD_SFTTREEM_SETTOPINDEX(hwnd, index, fn) \
    (int)(fn)((hwnd), SFTTREEM_SETTOPINDEX, (WPARAM)(index), (LPARAM)0)
#define SftTree_SetTopIndex(hwnd, index) \
                                FORWARD_SFTTREEM_SETTOPINDEX((hwnd), (index), SFTSEND)

/* void Cls_OnResetContent(HWND hwnd); */
#define HANDLE_SFTTREEM_RESETCONTENT(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd)), 0)
#define FORWARD_SFTTREEM_RESETCONTENT(hwnd, fn) \
    (void)(fn)((hwnd), SFTTREEM_RESETCONTENT, 0, 0)
#define SftTree_ResetContent(hwnd) \
                                FORWARD_SFTTREEM_RESETCONTENT((hwnd), SFTSEND)

/* int Cls_OnSelItemRange(HWND hwnd, BOOL fSelect, int nFirst, int nLast); */
#define HANDLE_SFTTREEM_SELITEMRANGE(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (int)LOWORD((lParam)), (int)HIWORD((lParam)) )
#define FORWARD_SFTTREEM_SELITEMRANGE(hwnd, fSelect, nFirst, nLast, fn) \
    (int)(fn)((hwnd), SFTTREEM_SELITEMRANGE, (BOOL)(fSelect), MAKELPARAM((nFirst), (nLast)))
#define SftTree_SelItemRange(hwnd, fSelect, nFirst, nLast) \
                                FORWARD_SFTTREEM_SELITEMRANGE((hwnd), (fSelect), (nFirst), (nLast), SFTSEND)

/* int Cls_OnGetParent(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_GETPARENT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam))
#define FORWARD_SFTTREEM_GETPARENT(hwnd, index, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETPARENT, (WPARAM)(index), 0)
#define SftTree_GetParent(hwnd, index) \
                                FORWARD_SFTTREEM_GETPARENT((hwnd), (index), SFTSEND)

/* int Cls_OnGetTopParent(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_GETTOPPARENT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam))
#define FORWARD_SFTTREEM_GETTOPPARENT(hwnd, index, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETTOPPARENT, (WPARAM)(index), 0)
#define SftTree_GetTopParent(hwnd, index) \
                                FORWARD_SFTTREEM_GETTOPPARENT((hwnd), (index), SFTSEND)

/* int Cls_OnGetSibling(HWND hwnd, int index, int type); */
#define HANDLE_SFTTREEM_GETSIBLING(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (int)(lParam))
#define FORWARD_SFTTREEM_GETSIBLING(hwnd, index, type, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETSIBLING, (WPARAM)(index), (LPARAM)(int)(type))
#define SftTree_GetSibling(hwnd, index, type) \
                                FORWARD_SFTTREEM_GETSIBLING((hwnd), (index), (type), SFTSEND)

/* int Cls_OnGetDependentCount(HWND hwnd, int index, BOOL fDepth); */
#define HANDLE_SFTTREEM_GETDEPENDENTCOUNT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (BOOL)(lParam))
#define FORWARD_SFTTREEM_GETDEPENDENTCOUNT(hwnd, index, type, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETDEPENDENTCOUNT, (WPARAM)(index), (LPARAM)(BOOL)(type))
#define SftTree_GetDependentCount(hwnd, index, fDepth) \
                                FORWARD_SFTTREEM_GETDEPENDENTCOUNT((hwnd), (index), (fDepth), SFTSEND)

/* int Cls_OnGetDependent(HWND hwnd, int index, int type); */
#define HANDLE_SFTTREEM_GETDEPENDENT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (int)(lParam))
#define FORWARD_SFTTREEM_GETDEPENDENT(hwnd, index, type, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETDEPENDENT, (WPARAM)(index), (LPARAM)(int)(type))
#define SftTree_GetDependent(hwnd, index, type) \
                                FORWARD_SFTTREEM_GETDEPENDENT((hwnd), (index), (type), SFTSEND)

/* int Cls_OnCalcIndexFromPoint(HWND hwnd, LPPOINT pt); */
#define HANDLE_SFTTREEM_CALCINDEXFROMPOINT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPPOINT) (lParam))
#define FORWARD_SFTTREEM_CALCINDEXFROMPOINT(hwnd, pt, fn) \
    (int)(fn)((hwnd), SFTTREEM_CALCINDEXFROMPOINT, 0, (LPARAM)(LPPOINT)(pt))
#define SftTree_CalcIndexFromPoint(hwnd, pt) \
                                FORWARD_SFTTREEM_CALCINDEXFROMPOINT((hwnd), (pt), SFTSEND)

/* BOOL Cls_OnGetShowLabels(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSHOWLABELS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSHOWLABELS(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETSHOWLABELS, 0, 0)
#define SftTree_GetShowLabels(hwnd) \
                                FORWARD_SFTTREEM_GETSHOWLABELS((hwnd), SFTSEND)

/* BOOL Cls_OnGetShowPlusMinus(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSHOWPLUSMINUS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSHOWPLUSMINUS(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETSHOWPLUSMINUS, 0, 0)
#define SftTree_GetShowPlusMinus(hwnd) \
                                FORWARD_SFTTREEM_GETSHOWPLUSMINUS((hwnd), SFTSEND)

/* BOOL Cls_OnSetPlusMinus(HWND hwnd, HBITMAP FAR *lphBitmap); */
#define HANDLE_SFTTREEM_SETPLUSMINUS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (HBITMAP FAR *)(lParam))
#define FORWARD_SFTTREEM_SETPLUSMINUS(hwnd, lphBitmap, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETPLUSMINUS, (WPARAM)0, (LPARAM)(HBITMAP FAR*)(lphBitmap))
#define SftTree_SetPlusMinus(hwnd, lphBitmap) \
                                FORWARD_SFTTREEM_SETPLUSMINUS((hwnd), (lphBitmap), SFTSEND)

/* BOOL Cls_OnGetShowTreeLines(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSHOWTREELINES(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSHOWTREELINES(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETSHOWTREELINES, 0, 0)
#define SftTree_GetShowTreeLines(hwnd) \
                                FORWARD_SFTTREEM_GETSHOWTREELINES((hwnd), SFTSEND)

/* void Cls_OnSetShowTreeLines(HWND hwnd, BOOL fSet); */
#define HANDLE_SFTTREEM_SETSHOWTREELINES(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (BOOL) (wParam)), 0l)
#define FORWARD_SFTTREEM_SETSHOWTREELINES(hwnd, fSet, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETSHOWTREELINES, (WPARAM)(fSet), 0)
#define SftTree_SetShowTreeLines(hwnd, fSet) \
                                FORWARD_SFTTREEM_SETSHOWTREELINES((hwnd), (fSet), SFTSEND)

/* BOOL Cls_OnSetBitmaps(HWND hwnd, HBITMAP FAR *lphBitmap); */
#define HANDLE_SFTTREEM_SETBITMAPS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (HBITMAP FAR *)(lParam))
#define FORWARD_SFTTREEM_SETBITMAPS(hwnd, lphBitmap, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETBITMAPS, (WPARAM)0, (LPARAM)(HBITMAP FAR*)(lphBitmap))
#define SftTree_SetBitmaps(hwnd, lphBitmap) \
                                FORWARD_SFTTREEM_SETBITMAPS((hwnd), (lphBitmap), SFTSEND)

/* BOOL Cls_OnGetShowBitmaps(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSHOWBITMAPS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSHOWBITMAPS(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETSHOWBITMAPS, 0, 0)
#define SftTree_GetShowBitmaps(hwnd) \
                                FORWARD_SFTTREEM_GETSHOWBITMAPS((hwnd), SFTSEND)

/* void Cls_OnSetSelTextOnly(HWND hwnd, BOOL fOnly); */
#define HANDLE_SFTTREEM_SETSELTEXTONLY(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (BOOL)(wParam)), 0L)
#define FORWARD_SFTTREEM_SETSELTEXTONLY(hwnd, fOnly, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETSELTEXTONLY, (WPARAM)(fOnly), 0)
#define SftTree_SetSelTextOnly(hwnd, fOnly) \
                                FORWARD_SFTTREEM_SETSELTEXTONLY((hwnd), (fOnly), SFTSEND)

/* BOOL Cls_OnGetSelTextOnly(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSELTEXTONLY(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSELTEXTONLY(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETSELTEXTONLY, 0, 0)
#define SftTree_GetSelTextOnly(hwnd) \
                                FORWARD_SFTTREEM_GETSELTEXTONLY((hwnd), SFTSEND)

/* LPSFTTREE_DRAGINFO Cls_OnGetDragInfo(HWND hwnd); */
#define HANDLE_SFTTREEM_GETDRAGINFO(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETDRAGINFO(hwnd, fn) \
    (LPSFTTREE_DRAGINFO)(fn)((hwnd), SFTTREEM_GETDRAGINFO, 0, 0)
#define SftTree_GetDragInfo(hwnd) \
                                FORWARD_SFTTREEM_GETDRAGINFO((hwnd), SFTSEND)

/* void Cls_OnSetDisableNoScroll(HWND hwnd, BOOL fDisable); */
#define HANDLE_SFTTREEM_SETDISABLENOSCROLL(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (BOOL)(wParam)), 0L)
#define FORWARD_SFTTREEM_SETDISABLENOSCROLL(hwnd, fDisable, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETDISABLENOSCROLL, (WPARAM)(fDisable), 0)
#define SftTree_SetDisableNoScroll(hwnd, fDisable) \
                                FORWARD_SFTTREEM_SETDISABLENOSCROLL((hwnd), (fDisable), SFTSEND)
#define SftTree_GetDisableNoScroll(hwnd) \
                                ((SFTGWLNG((hwnd), GWL_STYLE) & SFTTREESTYLE_DISABLENOSCROLL) != 0)

/* int Cls_OnGetColumns(HWND hwnd, LPSFTTREE_COLUMN FAR * lpCol); */
#define HANDLE_SFTTREEM_GETCOLUMNS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPSFTTREE_COLUMN FAR *) (lParam))
#define FORWARD_SFTTREEM_GETCOLUMNS(hwnd, lplpCol, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETCOLUMNS, 0, (LPARAM)(LPSFTTREE_COLUMN FAR *)(lplpCol))
#define SftTree_GetColumns(hwnd, lpColArray) \
                                FORWARD_SFTTREEM_GETCOLUMNS((hwnd), (lpColArray), SFTSEND)

/* BOOL Cls_OnSetColumns(HWND hwnd, int count, LPSFTTREE_COLUMN lpCols); */
#define HANDLE_SFTTREEM_SETCOLUMNS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam), (LPSFTTREE_COLUMN)(lParam))
#define FORWARD_SFTTREEM_SETCOLUMNS(hwnd, count, lpCols, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETCOLUMNS, (WPARAM)(count), (LPARAM)(LPSFTTREE_COLUMN)(lpCols))
#define SftTree_SetColumns(hwnd, count, lpColArray) \
                                FORWARD_SFTTREEM_SETCOLUMNS((hwnd), (count), (lpColArray), SFTSEND)

/* BOOL Cls_OnSetButtons(HWND hwnd, HBITMAP hButtons); */
#define HANDLE_SFTTREEM_SETBUTTONS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (HBITMAP)(UINT)(lParam))
#define FORWARD_SFTTREEM_SETBUTTONS(hwnd, hButtons, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETBUTTONS, 0, (LPARAM)(UINT)(hButtons))
#define SftTree_SetButtons(hwnd, hButton) \
                                FORWARD_SFTTREEM_SETBUTTONS((hwnd), (hButton), SFTSEND)

/* BOOL Cls_OnGetShowButtons(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSHOWBUTTONS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSHOWBUTTONS(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETSHOWBUTTONS, 0, 0)
#define SftTree_GetShowButtons(hwnd) \
                                FORWARD_SFTTREEM_GETSHOWBUTTONS((hwnd), SFTSEND)

/* void Cls_OnSetShowButtons(HWND hwnd, BOOL fSet); */
#define HANDLE_SFTTREEM_SETSHOWBUTTONS(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (BOOL) (wParam)), 0l)
#define FORWARD_SFTTREEM_SETSHOWBUTTONS(hwnd, fSet, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETSHOWBUTTONS, (WPARAM)(fSet), 0)
#define SftTree_SetShowButtons(hwnd, fSet) \
                                FORWARD_SFTTREEM_SETSHOWBUTTONS((hwnd), (fSet), SFTSEND)

/* BOOL Cls_OnGetShowButton0(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSHOWBUTTON0(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSHOWBUTTON0(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETSHOWBUTTON0, 0, 0)
#define SftTree_GetShowButton0(hwnd) \
                                FORWARD_SFTTREEM_GETSHOWBUTTON0((hwnd), SFTSEND)

/* void Cls_OnSetShowButton0(HWND hwnd, BOOL fSet); */
#define HANDLE_SFTTREEM_SETSHOWBUTTON0(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (BOOL) (wParam)), 0l)
#define FORWARD_SFTTREEM_SETSHOWBUTTON0(hwnd, fSet, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETSHOWBUTTON0, (WPARAM)(fSet), 0)
#define SftTree_SetShowButton0(hwnd, fSet) \
                                FORWARD_SFTTREEM_SETSHOWBUTTON0((hwnd), (fSet), SFTSEND)

/* int Cls_OnGetHorizontalExtent(HWND hwnd); */
#define HANDLE_SFTTREEM_GETHORIZONTALEXTENT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETHORIZONTALEXTENT(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETHORIZONTALEXTENT, 0, 0L)
#define SftTree_GetHorizontalExtent(hwnd) \
                                FORWARD_SFTTREEM_GETHORIZONTALEXTENT((hwnd), SFTSEND)

/* BOOL Cls_OnSetHorizontalExtent(HWND hwnd, int width); */
#define HANDLE_SFTTREEM_SETHORIZONTALEXTENT(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (int)(wParam)), 0L)
#define FORWARD_SFTTREEM_SETHORIZONTALEXTENT(hwnd, width, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETHORIZONTALEXTENT, (WPARAM)(width), 0L)
#define SftTree_SetHorizontalExtent(hwnd, width) \
                                FORWARD_SFTTREEM_SETHORIZONTALEXTENT((hwnd), (width), SFTSEND)

/* void Cls_OnRecalcHorizontalExtent(HWND hwnd); */
#define HANDLE_SFTTREEM_RECALCHORIZONTALEXTENT(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd)), 0L)
#define FORWARD_SFTTREEM_RECALCHORIZONTALEXTENT(hwnd, fn) \
    (void)(fn)((hwnd), SFTTREEM_RECALCHORIZONTALEXTENT, 0, 0L)
#define SftTree_RecalcHorizontalExtent(hwnd) \
                                FORWARD_SFTTREEM_RECALCHORIZONTALEXTENT((hwnd), SFTSEND)

/* int Cls_OnGetHorizontalOffset(HWND hwnd); */
#define HANDLE_SFTTREEM_GETHORIZONTALOFFSET(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETHORIZONTALOFFSET(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETHORIZONTALOFFSET, 0, 0L)
#define SftTree_GetHorizontalOffset(hwnd) \
                                FORWARD_SFTTREEM_GETHORIZONTALOFFSET((hwnd), SFTSEND)

/* BOOL Cls_OnSetHorizontalOffset(HWND hwnd, int width); */
#define HANDLE_SFTTREEM_SETHORIZONTALOFFSET(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (int)(wParam)), 0L)
#define FORWARD_SFTTREEM_SETHORIZONTALOFFSET(hwnd, width, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETHORIZONTALOFFSET, (WPARAM)(width), 0L)
#define SftTree_SetHorizontalOffset(hwnd, width) \
                                FORWARD_SFTTREEM_SETHORIZONTALOFFSET((hwnd), (width), SFTSEND)

/* BOOL Cls_OnSetItemLines(HWND hwnd, int nLines); */
#define HANDLE_SFTTREEM_SETITEMLINES(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (int)(wParam)), 0L)
#define FORWARD_SFTTREEM_SETITEMLINES(hwnd, nLines, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETITEMLINES, (WPARAM)(nLines), 0L)
#define SftTree_SetItemLines(hwnd, nLines) \
                                FORWARD_SFTTREEM_SETITEMLINES((hwnd), (nLines), SFTSEND)

/* int Cls_OnGetItemLines(HWND hwnd); */
#define HANDLE_SFTTREEM_GETITEMLINES(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETITEMLINES(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETITEMLINES, 0, 0L)
#define SftTree_GetItemLines(hwnd) \
                                FORWARD_SFTTREEM_GETITEMLINES((hwnd), SFTSEND)

/* int Cls_OnGetAccessColumn(HWND hwnd); */
#define HANDLE_SFTTREEM_GETACCESSCOLUMN(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETACCESSCOLUMN(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETACCESSCOLUMN, 0, 0L)
#define SftTree_GetAccessColumn(hwnd) \
                                FORWARD_SFTTREEM_GETACCESSCOLUMN((hwnd), SFTSEND)

/* int Cls_OnSetAccessColumn(HWND hwnd, int col); */
#define HANDLE_SFTTREEM_SETACCESSCOLUMN(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (int)(wParam)), 0L)
#define FORWARD_SFTTREEM_SETACCESSCOLUMN(hwnd, col, fn) \
    (int)(fn)((hwnd), SFTTREEM_SETACCESSCOLUMN, (WPARAM)(col), 0L)
#define SftTree_SetAccessColumn(hwnd, col) \
                                FORWARD_SFTTREEM_SETACCESSCOLUMN((hwnd), (col), SFTSEND)

/* void Cls_OnSetHeaderFont(HWND hwnd, HFONT hfont, BOOL fRedraw); */
#define HANDLE_SFTTREEM_SETHEADERFONT(hwnd, wParam, lParam, fn) \
    ((fn)((hwnd), (HFONT)(wParam), (BOOL)LOWORD(lParam)), 0L)
#define FORWARD_SFTTREEM_SETHEADERFONT(hwnd, hfont, fRedraw, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETHEADERFONT, (WPARAM)(HFONT)(hfont), MAKELPARAM((UINT)(BOOL)(fRedraw), 0))
#define SftTree_SetHeaderFont(hwnd, hFont, fRepaint) \
                                FORWARD_SFTTREEM_SETHEADERFONT((hwnd), (hFont), (fRepaint), SFTSEND)

/* HFONT Cls_OnGetHeaderFont(HWND hwnd); */
#define HANDLE_SFTTREEM_GETHEADERFONT(hwnd, wParam, lParam, fn) \
    (LRESULT)(DWORD)(UINT)(HFONT)(fn)(hwnd)
#define FORWARD_SFTTREEM_GETHEADERFONT(hwnd, fn) \
    (HFONT)(UINT)(DWORD)(fn)((hwnd), SFTTREEM_GETHEADERFONT, 0, 0L)
#define SftTree_GetHeaderFont(hwnd) \
                                FORWARD_SFTTREEM_GETHEADERFONT((hwnd), SFTSEND)

/* BOOL Cls_OnGetShowHeader(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSHOWHEADER(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSHOWHEADER(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETSHOWHEADER, 0, 0)
#define SftTree_GetShowHeader(hwnd) \
                                FORWARD_SFTTREEM_GETSHOWHEADER((hwnd), SFTSEND)

/* void Cls_OnSetShowHeader(HWND hwnd, BOOL fSet); */
#define HANDLE_SFTTREEM_SETSHOWHEADER(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (BOOL) (wParam)), 0l)
#define FORWARD_SFTTREEM_SETSHOWHEADER(hwnd, fSet, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETSHOWHEADER, (WPARAM)(fSet), 0)
#define SftTree_SetShowHeader(hwnd, fSet) \
                                FORWARD_SFTTREEM_SETSHOWHEADER((hwnd), (fSet), SFTSEND)

/* BOOL Cls_OnGetShow3D(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSHOW3D(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSHOW3D(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETSHOW3D, 0, 0)
#define SftTree_GetShow3D(hwnd) \
                                FORWARD_SFTTREEM_GETSHOW3D((hwnd), SFTSEND)

/* void Cls_OnSetShow3D(HWND hwnd, BOOL fSet); */
#define HANDLE_SFTTREEM_SETSHOW3D(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (BOOL) (wParam)), 0l)
#define FORWARD_SFTTREEM_SETSHOW3D(hwnd, fSet, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETSHOW3D, (WPARAM)(fSet), 0)
#define SftTree_SetShow3D(hwnd, fSet) \
                                FORWARD_SFTTREEM_SETSHOW3D((hwnd), (fSet), SFTSEND)

/* BOOL Cls_OnGetShowGrid(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSHOWGRID(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSHOWGRID(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETSHOWGRID, 0, 0)
#define SftTree_GetShowGrid(hwnd) \
                                FORWARD_SFTTREEM_GETSHOWGRID((hwnd), SFTSEND)

/* void Cls_OnSetShowGrid(HWND hwnd, BOOL fSet); */
#define HANDLE_SFTTREEM_SETSHOWGRID(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (BOOL) (wParam)), 0l)
#define FORWARD_SFTTREEM_SETSHOWGRID(hwnd, fSet, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETSHOWGRID, (WPARAM)(fSet), 0)
#define SftTree_SetShowGrid(hwnd, fSet) \
                                FORWARD_SFTTREEM_SETSHOWGRID((hwnd), (fSet), SFTSEND)

/* BOOL Cls_OnSortDependents(HWND hwnd, int index, SFTTREE_SORTPROC lpfnCompare); */
#define HANDLE_SFTTREEM_SORTDEPENDENTS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (SFTTREE_SORTPROC)(lParam))
#define FORWARD_SFTTREEM_SORTDEPENDENTS(hwnd, index, lpfnCompare, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SORTDEPENDENTS, (WPARAM)(index), (LPARAM)(SFTTREE_SORTPROC)(lpfnCompare))
#define SftTree_SortDependents(hwnd, index, lpfnCompare) \
                                FORWARD_SFTTREEM_SORTDEPENDENTS((hwnd), (index), (lpfnCompare), SFTSEND)

/* BOOL Cls_OnGetShowHeaderButtons(HWND hwnd); */
#define HANDLE_SFTTREEM_GETSHOWHEADERBUTTONS(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETSHOWHEADERBUTTONS(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETSHOWHEADERBUTTONS, 0, 0)
#define SftTree_GetShowHeaderButtons(hwnd) \
                                FORWARD_SFTTREEM_GETSHOWHEADERBUTTONS((hwnd), SFTSEND)

/* void Cls_OnSetShowHeaderButtons(HWND hwnd, BOOL fSet); */
#define HANDLE_SFTTREEM_SETSHOWHEADERBUTTONS(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (BOOL) (wParam)), 0l)
#define FORWARD_SFTTREEM_SETSHOWHEADERBUTTONS(hwnd, fSet, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETSHOWHEADERBUTTONS, (WPARAM)(fSet), 0)
#define SftTree_SetShowHeaderButtons(hwnd, fSet) \
                                FORWARD_SFTTREEM_SETSHOWHEADERBUTTONS((hwnd), (fSet), SFTSEND)

/* int Cls_OnGetHeaderButton(HWND hwnd); */
#define HANDLE_SFTTREEM_GETHEADERBUTTON(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETHEADERBUTTON(hwnd, fn) \
    (int)(fn)((hwnd), SFTTREEM_GETHEADERBUTTON, 0, 0)
#define SftTree_GetHeaderButton(hwnd) \
                                FORWARD_SFTTREEM_GETHEADERBUTTON((hwnd), SFTSEND)

/* void Cls_OnSetHeaderButton(HWND hwnd, int col); */
#define HANDLE_SFTTREEM_SETHEADERBUTTON(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (int) (wParam)), 0l)
#define FORWARD_SFTTREEM_SETHEADERBUTTON(hwnd, col, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETHEADERBUTTON, (WPARAM)(col), 0)
#define SftTree_SetHeaderButton(hwnd, col) \
                                FORWARD_SFTTREEM_SETHEADERBUTTON((hwnd), (col), SFTSEND)

/* BOOL Cls_OnSetDrawInfoCallback(HWND hwnd, LPSFTTREE_DRAWINFOPARM lpDrawInfo); */
#define HANDLE_SFTTREEM_SETDRAWINFOCALLBACK(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (LPSFTTREE_DRAWINFOPARM)(lParam))
#define FORWARD_SFTTREEM_SETDRAWINFOCALLBACK(hwnd, lpfnDrawInfo, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_SETDRAWINFOCALLBACK, 0, (LPARAM)(LPSFTTREE_DRAWINFOPARM)(lpfnDrawInfo))
#define SftTree_SetDrawInfoCallback(hwnd, lpDrawInfo) \
                                FORWARD_SFTTREEM_SETDRAWINFOCALLBACK((hwnd), (lpDrawInfo), SFTSEND)

/* BOOL Cls_OnGetResizeHeader(HWND hwnd); */
#define HANDLE_SFTTREEM_GETRESIZEHEADER(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd))
#define FORWARD_SFTTREEM_GETRESIZEHEADER(hwnd, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_GETRESIZEHEADER, 0, 0)
#define SftTree_GetResizeHeader(hwnd) \
                                FORWARD_SFTTREEM_GETRESIZEHEADER((hwnd), SFTSEND)

/* void Cls_OnSetResizeHeader(HWND hwnd, BOOL fSet); */
#define HANDLE_SFTTREEM_SETRESIZEHEADER(hwnd, wParam, lParam, fn) \
    (LRESULT)((fn)((hwnd), (BOOL) (wParam)), 0l)
#define FORWARD_SFTTREEM_SETRESIZEHEADER(hwnd, fSet, fn) \
    (void)(fn)((hwnd), SFTTREEM_SETRESIZEHEADER, (WPARAM)(fSet), 0)
#define SftTree_SetResizeHeader(hwnd, fSet) \
                                FORWARD_SFTTREEM_SETRESIZEHEADER((hwnd), (fSet), SFTSEND)

/* LPRECT Cls_OnGetEditColumnRect(HWND hwnd, int index, LPINT lpCol); */
#define HANDLE_SFTTREEM_GETEDITCOLUMNRECT(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int) (wParam), (LPINT)(lParam))
#define FORWARD_SFTTREEM_GETEDITCOLUMNRECT(hwnd, index, lpCol, fn) \
    (LPRECT)(fn)((hwnd), SFTTREEM_GETEDITCOLUMNRECT, (WPARAM)(index), (LPARAM)(LPINT)(lpCol))
#define SftTree_GetEditColumnRect(hwnd, index, lpCol) \
                                FORWARD_SFTTREEM_GETEDITCOLUMNRECT((hwnd), (index), (lpCol), SFTSEND)

/* BOOL Cls_OnEnsureVisible(HWND hwnd, int index); */
#define HANDLE_SFTTREEM_ENSUREVISIBLE(hwnd, wParam, lParam, fn) \
    (LRESULT)(fn)((hwnd), (int)(wParam))
#define FORWARD_SFTTREEM_ENSUREVISIBLE(hwnd, index, fn) \
    (BOOL)(fn)((hwnd), SFTTREEM_ENSUREVISIBLE, (WPARAM)(index), (LPARAM)(0))
#define SftTree_EnsureVisible(hwnd, index) \
                                FORWARD_SFTTREEM_ENSUREVISIBLE((hwnd), (index), SFTSEND)

#if defined(__cplusplus)
} /* extern "C" */
#endif


/* Microsoft Foundation Class Library Support */
/* Microsoft Foundation Class Library Support */
/* Microsoft Foundation Class Library Support */

#if defined(__AFX_H__) && defined(__cplusplus)

#include "SftTreeM.H"                   /* SftTree MFC Support */

#endif /* Microsoft Foundation Class Library Support */

/* ObjectWindows Library Support */
/* ObjectWindows Library Support */
/* ObjectWindows Library Support */

#if defined(OWL_OWLALL_H) && defined(__cplusplus)

#include "SftTreeB.H"                   /* SftTree OWL Support */

#endif

#endif  /* !RC_INVOKED */

#endif /* _INC_SFTTREE */
