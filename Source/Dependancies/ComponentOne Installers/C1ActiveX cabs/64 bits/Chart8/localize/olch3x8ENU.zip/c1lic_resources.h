//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by c1lic_dialogs.rc
//
#define IDD_C1LIC_ABOUT                 1976
#define IDD_C1LIC_BETA                  1977
#define IDD_C1LIC_LICENSING             1979
#define IDB_LOGO_SMALL                  1980
#define IDB_C1LOGO_LINES                2976
#define IDB_C1LOGO                      2977
#define IDC_BUTTON1                     4000
#define IDC_LICENSEBTN                  4000
#define IDC_COPYRIGHT                   4001
#define IDC_STUDIONOTE                  4002
#define IDC_VERSION                     4003
#define IDC_VER_LABEL                   4004
#define IDC_PRODUCTNAME                 4005
#define IDC_NOTLICENSED                 4006
#define IDC_REGISTERBTN                 4007
#define IDC_PURCHASEBTN                 4008
#define IDC_TRIALPERIOD                 4009
#define IDC_RUNTIME1                    4010
#define IDC_RUNTIME2                    4011
#define IDC_SUPPORTMAIL                 4012
#define IDC_C1TECHSUPPORT               4013
#define IDC_CONTACTUS                   4014
#define IDC_WWW                         4015
#define IDC_UPDATES                     4016
#define IDC_STORE                       4017
#define IDC_RESELLERS                   4018
#define IDC_NEWSGROUP                   4019
#define IDC_EMAIL_LABEL                 4020
#define IDC_ONLINE_LABEL                4021
#define IDC_EXPIRED                     4022
#define IDC_BETAFEEDBACK                4024
#define IDC_BETAVERSION                 4025
#define IDC_BETARECT                    4026
#define IDC_NAME                        4030
#define IDC_COMPANY                     4031
#define IDC_SN                          4032
#define IDC_AGREEMENT                   4033
#define IDC_CUSTOMERNAME                4034
#define IDC_CUSTOMERCOMPANY             4035
#define IDC_LICENSEDTO                  4036
#define IDC_CHOOSEPROD                  4037
#define IDC_RECT                        4038
#define IDC_C1GC_INFO                   4039
#define IDC_JPMSG1                      4100
#define IDC_JPMSG2                      4101
#define IDC_JPMSG3                      4102
#define IDS_C1LIC_WWW                   5000
#define IDS_C1LIC_NAMEEXCEEDS           5001
#define IDS_C1LIC_COMPANYEXCEEDS        5002
#define IDS_C1LIC_LICOK                 5003
#define IDS_C1LIC_EXPIRED               5004
#define IDS_C1LIC_ERRMSG_NONE           5005
#define IDS_C1LIC_ERRMSG_INVALID_SN     5006
#define IDS_C1LIC_ERRMSG_ENCRYPT        5007
#define IDS_C1LIC_ERRMSG_DECRYPT        5008
#define IDS_C1LIC_ERR_INV_DATA          5009
#define IDS_C1LIC_ERRMSG_ARCHAIC        5010
#define IDS_C1LIC_ERRMSG_ERROR          5011
#define IDS_C1LIC_ERRMSG_LINK           5012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         4042
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
