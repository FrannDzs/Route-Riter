/****************************************************************************/
/* SftTree 1.0 - Tree Custom Control for Windows                            */
/* Copyright (C) 1995  Softel vdm. All Rights Reserved.                     */
/****************************************************************************/

#if !defined(_INC_SFTAPPTREE)
#define _INC_SFTAPPTREE                             /* only include once */

#if defined(__cplusplus)
extern "C" {
#endif

// Resources

// CURSORs
#define IDC_TREECTRL_NODROP         32600
#define IDC_TREECTRL_DRAG           32601
#define IDC_TREECTRL_LEFTRIGHT      32602
//BITMAPS
#define IDB_TREECTRL_BUTTONS        32600

// Functions

BOOL WINAPI SftTree_RegisterClass(HINSTANCE hInst, HINSTANCE hInstPrev, BOOL fDLL);
void WINAPI SftTree_UnregisterClass(HINSTANCE hInst);

#if defined(__cplusplus)
} /* extern "C" */
#endif

#endif /* _INC_SFTAPPTREE */
