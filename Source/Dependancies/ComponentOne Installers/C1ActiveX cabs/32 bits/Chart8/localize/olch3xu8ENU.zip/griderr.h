#ifndef SPREADERROR_INCLUDED
#define SPREADERROR_INCLUDED

// error codes for various grid functions

#define GRID_BASE                   3000
#define GRID_ERROR                  (GRID_BASE + 1)
#define GRID_ALLOC_ERROR            (GRID_BASE + 2)

#define ENTRY_BASE                  GRID_BASE + 20
#define ENTRY_OK                    (ENTRY_BASE + 1)
#define ENTRY_BAD_FLOAT             (ENTRY_BASE + 2)
#define ENTRY_BAD_NUMBER            (ENTRY_BASE + 3)
#define ENTRY_READONLY              (ENTRY_BASE + 4)

// PlaceEntryField() return codes (and string ids)
#define ENTRY_BAD_TYPE_CONVERSION   (ENTRY_BASE + 11)
#define ENTRY_BAD_VALIDATION        (ENTRY_BASE + 12)
#define ENTRY_BAD_TYPE_COPY         (ENTRY_BASE + 13)
#define ENTRY_BAD_PLACEMENT         (ENTRY_BASE + 14)
#define ENTRY_BAD_MODIFICATION      (ENTRY_BASE + 15)

// GridGetString() codes for clipboard errors
#define CLIP_BASE                   GRID_BASE + 40
#define CLIP_ENTIRE_ROW             (CLIP_BASE + 1)
#define CLIP_NO_ROOM                (CLIP_BASE + 2)
#define CLIP_NOTHING_TO_PASTE       (CLIP_BASE + 3)
#define CLIP_NOTHING_TO_UNDO        (CLIP_BASE + 4)
#define CLIP_CANNOT_UNDO_FILL       (CLIP_BASE + 5)
#define CLIP_ORIGIN_EMPTY           (CLIP_BASE + 6)


#endif
