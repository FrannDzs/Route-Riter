#include "Windows.H"

BOOL WINAPI DllMain(HINSTANCE hInst, ULONG ulReason, LPVOID pReserved)
{
        return TRUE;
}

