/****************************************************************************/
/* SFTTABS 2.0 - Tab Custom Control for Windows                             */
/* Copyright (C) 1994, 1995  Softel vdm. All Rights Reserved.               */
/****************************************************************************/

#if !defined(_INC_SFTAPPTABS)
#define _INC_SFTAPPTABS                             /* only include once */

#if defined(__cplusplus)
extern "C" {
#endif

// Resources

#define IDB_SFTTABS_BITMAP1     32700    // scroll button bitmaps
#define IDB_SFTTABS_BITMAP2     32701
#define IDB_SPIRAL_TOP          32702    // spiral bitmaps (notebook)
#define IDB_SPIRAL_LEFT         32703
#define IDB_SPIRALW_TOP         32704
#define IDB_SPIRALW_LEFT        32705
#define IDB_3RING_TOP           32706    // 3-ring bitmaps (notebook)
#define IDB_3RING_LEFT          32707
#define IDB_3RING_TOP_CLEAR     32708
#define IDB_3RING_LEFT_CLEAR    32709
#define IDB_3RINGW_TOP          32710
#define IDB_3RINGW_LEFT         32711
#define IDB_3RINGW_TOP_CLEAR    32712
#define IDB_3RINGW_LEFT_CLEAR   32713

// Functions

BOOL WINAPI SftTabs_RegisterClass(HINSTANCE hInst, HINSTANCE hInstPrev, BOOL fDLL);
void WINAPI SftTabs_UnregisterClass(HINSTANCE hInst);

#if defined(__cplusplus)
} /* extern "C" */
#endif

#endif /* _INC_SFTAPPTABS */

